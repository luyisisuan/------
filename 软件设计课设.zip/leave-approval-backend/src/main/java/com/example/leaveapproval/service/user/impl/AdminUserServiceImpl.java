package com.example.leaveapproval.service.user.impl; // <<--- 注意包名变化

import com.example.leaveapproval.dto.AdminUserCreateRequest;
import com.example.leaveapproval.dto.UserDto;
import com.example.leaveapproval.dto.UserUpdateRequest;
import com.example.leaveapproval.exception.ResourceNotFoundException;
import com.example.leaveapproval.model.User;
import com.example.leaveapproval.repository.UserRepository;
import com.example.leaveapproval.service.user.AdminUserService; // <<--- 确保导入正确的接口路径
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.Optional;

/**
 * {@link AdminUserService} 接口的实现类。
 * 提供了管理员管理用户账户的具体业务逻辑。
 */
@Service // 标记为Spring的服务组件
@Transactional // 默认该类所有公共方法都纳入Spring事务管理
public class AdminUserServiceImpl implements AdminUserService {

    private static final Logger logger = LoggerFactory.getLogger(AdminUserServiceImpl.class);

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    /**
     * 通过构造函数注入依赖。
     * @param userRepository 用户数据仓库。
     * @param passwordEncoder 密码编码器。
     */
    @Autowired
    public AdminUserServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional(readOnly = true) // 读取操作优化，设置为只读事务
    public Page<UserDto> getAllUsers(Pageable pageable) {
        logger.info("管理员操作：获取所有用户，分页参数：{}", pageable);
        return userRepository.findAll(pageable).map(UserDto::fromEntity);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<UserDto> getUserById(Long id) {
        logger.info("管理员操作：根据ID获取用户，用户ID：{}", id);
        return userRepository.findById(id).map(UserDto::fromEntity);
    }

    @Override
    public UserDto createUser(AdminUserCreateRequest createRequest) {
        logger.info("管理员操作：尝试创建新用户，用户名：{}", createRequest.getUsername());

        // 检查用户名是否已存在
        if (userRepository.existsByUsername(createRequest.getUsername())) {
            String errorMessage = "错误：用户名 '" + createRequest.getUsername() + "' 已被占用！";
            logger.warn(errorMessage);
            throw new DataIntegrityViolationException(errorMessage);
        }
        // 检查邮箱是否已存在
        if (userRepository.existsByEmail(createRequest.getEmail())) {
            String errorMessage = "错误：邮箱 '" + createRequest.getEmail() + "' 已被使用！";
            logger.warn(errorMessage);
            throw new DataIntegrityViolationException(errorMessage);
        }
        // 检查角色是否已分配
        if (createRequest.getRoles() == null || createRequest.getRoles().isEmpty()) {
            String errorMessage = "错误：管理员创建用户时必须分配角色。";
            logger.warn(errorMessage);
            throw new IllegalArgumentException(errorMessage);
        }

        User user = new User();
        user.setUsername(createRequest.getUsername());
        user.setPassword(passwordEncoder.encode(createRequest.getPassword())); // 加密密码
        user.setFullName(createRequest.getFullName());
        user.setEmail(createRequest.getEmail());

        // 设置部门（如果DTO中提供了）
        if (StringUtils.hasText(createRequest.getDepartment())) {
            user.setDepartment(createRequest.getDepartment());
        }

        // 设置直属上级（如果DTO中提供了）
        if (createRequest.getManagerId() != null) {
            User manager = userRepository.findById(createRequest.getManagerId())
                    .orElseThrow(() -> {
                        String errorMessage = "指定的上级用户 (ID: " + createRequest.getManagerId() + ") 不存在。";
                        logger.warn(errorMessage);
                        return new ResourceNotFoundException("Manager", "id", createRequest.getManagerId());
                    });
            user.setManager(manager);
        }

        user.setRoles(createRequest.getRoles());
        user.setEnabled(true); // 新用户默认启用

        User savedUser = userRepository.save(user);
        logger.info("管理员操作：用户创建成功，用户ID：{}", savedUser.getId());
        return UserDto.fromEntity(savedUser);
    }

    @Override
    public Optional<UserDto> updateUser(Long id, UserUpdateRequest updateRequest) {
        logger.info("管理员操作：尝试更新用户，用户ID：{}", id);

        // 使用 flatMap 而不是 map，因为 lambda 表达式内部返回的是 Optional<UserDto>
        return userRepository.findById(id).flatMap(user -> { // <<--- 修改这里：使用 flatMap
            boolean isModified = false;

            if (StringUtils.hasText(updateRequest.getFullName()) && !updateRequest.getFullName().equals(user.getFullName())) {
                user.setFullName(updateRequest.getFullName());
                isModified = true;
            }

            if (StringUtils.hasText(updateRequest.getEmail()) && !updateRequest.getEmail().equals(user.getEmail())) {
                Optional<User> existingUserWithEmail = userRepository.findByEmail(updateRequest.getEmail());
                if (existingUserWithEmail.isPresent() && !existingUserWithEmail.get().getId().equals(user.getId())) {
                    String errorMessage = "错误：邮箱 '" + updateRequest.getEmail() + "' 已被其他用户使用！";
                    logger.warn(errorMessage);
                    throw new DataIntegrityViolationException(errorMessage);
                }
                user.setEmail(updateRequest.getEmail());
                isModified = true;
            }

            if (updateRequest.getDepartment() != null && !updateRequest.getDepartment().equals(user.getDepartment())) {
                user.setDepartment(updateRequest.getDepartment());
                isModified = true;
            }

            if (updateRequest.getManagerId() != null) {
                if (user.getManager() == null || !updateRequest.getManagerId().equals(user.getManager().getId())) {
                    if (updateRequest.getManagerId().equals(user.getId())) {
                        String errorMsg = "错误：用户不能将自己设置为其直属上级。用户ID: " + id;
                        logger.warn(errorMsg);
                        throw new IllegalArgumentException(errorMsg);
                    }
                    User manager = userRepository.findById(updateRequest.getManagerId())
                            .orElseThrow(() -> {
                                String errorMessage = "指定的上级用户 (ID: " + updateRequest.getManagerId() + ") 不存在。";
                                logger.warn(errorMessage);
                                return new ResourceNotFoundException("Manager", "id", updateRequest.getManagerId());
                            });
                    user.setManager(manager);
                    isModified = true;
                }
            } else if (updateRequest.getManagerId() == null && user.getManager() != null) {
                user.setManager(null);
                isModified = true;
            }

            if (updateRequest.getRoles() != null && !updateRequest.getRoles().isEmpty()) {
                if (!user.getRoles().equals(updateRequest.getRoles())) {
                    user.setRoles(updateRequest.getRoles());
                    isModified = true;
                }
            } else if (updateRequest.getRoles() != null && updateRequest.getRoles().isEmpty()){
                String errorMessage = "错误：更新用户时角色列表不能为空。如需禁用用户，请使用 'enabled' 标志。";
                logger.warn(errorMessage);
                throw new IllegalArgumentException(errorMessage);
            }

            if (updateRequest.getEnabled() != null && updateRequest.getEnabled() != user.isEnabled()) {
                user.setEnabled(updateRequest.getEnabled());
                isModified = true;
            }

            if (isModified) {
                User updatedUser = userRepository.save(user);
                logger.info("管理员操作：用户更新成功，用户ID：{}", updatedUser.getId());
                return Optional.of(UserDto.fromEntity(updatedUser)); // lambda 返回 Optional<UserDto>
            } else {
                logger.info("管理员操作：未检测到用户信息的实际更改，用户ID：{}。返回现有数据。", id);
                return Optional.of(UserDto.fromEntity(user)); // lambda 返回 Optional<UserDto>
            }
        });
    }
    @Override
    public void deleteUser(Long id) {
        logger.info("管理员操作：尝试删除用户，用户ID：{}", id);
        if (!userRepository.existsById(id)) {
            String errorMessage = "错误：尝试删除的用户 (ID: " + id + ") 不存在。";
            logger.warn(errorMessage);
            throw new ResourceNotFoundException("User", "id", id);
        }
        // 此处可以添加更复杂的业务逻辑，例如检查用户是否有关联的未完成任务等
        userRepository.deleteById(id);
        logger.info("管理员操作：用户删除成功，用户ID：{}", id);
    }
}