<script setup>
import Navbar from './components/layout/Navbar.vue';
</script>

<template>
  <div id="app-layout">
    <Navbar />
    <main class="main-content">
      <router-view />
    </main>
  </div>
</template>

<style scoped>
#app-layout {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  background-color: #f8f9fa;
}
.main-content {
  flex-grow: 1;
  padding: 1.5rem;
}
</style>