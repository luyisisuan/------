<script setup>
import { computed } from 'vue';
import { useRouter } from 'vue-router'; // 引入 useRouter 用于编程式导航登出后跳转
import { useAuthStore } from '../../stores/auth'; // 假设你的 auth store 在这个路径

const authStore = useAuthStore();
const router = useRouter(); // 获取 router 实例

// 用户显示名称，优先显示全名，其次是用户名，最后是“游客”
const currentUserDisplay = computed(() => {
  if (authStore.currentUser) {
    return authStore.currentUser.fullName || authStore.currentUser.username || '未知用户';
  }
  return '游客';
});

// 判断用户是否至少拥有一个“审批者”角色（团队领导、部门经理、HR）或管理员角色
const canApprove = computed(() => {
  if (!authStore.isAuthenticated || !authStore.userRoles) {
    return false;
  }
  const approverRoles = ['ROLE_TEAM_LEAD', 'ROLE_DEPT_MANAGER', 'ROLE_HR', 'ROLE_ADMIN'];
  return authStore.userRoles.some(role => approverRoles.includes(role));
});

// 判断用户是否是管理员
const isAdmin = computed(() => {
  if (!authStore.isAuthenticated || !authStore.userRoles) {
    return false;
  }
  return authStore.userRoles.includes('ROLE_ADMIN');
});

// 登出操作
const handleLogout = async () => {
  try {
    await authStore.logout(); // 调用 store 中的 logout 方法
    // 登出成功后，authStore.logout 内部应该处理了跳转到登录页的逻辑
    // 如果没有，可以在这里手动添加：router.push('/login');
  } catch (error) {
    console.error('登出失败:', error);
    // 这里可以添加一些用户提示，例如使用一个通知库
  }
};
</script>

<template>
  <nav class="navbar">
    <div class="navbar-brand">
      <router-link to="/" class="navbar-logo">请假审批系统</router-link>
    </div>
    <div class="navbar-menu">
      <!-- 已认证用户导航 -->
      <template v-if="authStore.isAuthenticated">
        <router-link to="/dashboard" class="navbar-item" active-class="is-active">仪表盘</router-link>
        <router-link to="/submit-leave" class="navbar-item" active-class="is-active">提交请假</router-link>
        <router-link to="/my-requests" class="navbar-item" active-class="is-active">我的申请</router-link>

        <!-- “待我审批”链接，基于角色判断 -->
        <router-link
          v-if="canApprove"
          to="/pending-approvals"
          class="navbar-item"
          active-class="is-active"
        >
          待我审批
        </router-link>

        <!-- “用户管理”链接，仅限管理员 -->
        <router-link
          v-if="isAdmin"
          to="/admin/users"
          class="navbar-item"
          active-class="is-active"
        >
          用户管理
        </router-link>

        <div class="navbar-end">
          <span class="navbar-item user-info">你好, {{ currentUserDisplay }}</span>
          <button @click="handleLogout" class="navbar-item logout-button">登出</button>
        </div>
      </template>

      <!-- 未认证用户导航 -->
      <template v-else>
        <router-link to="/login" class="navbar-item" active-class="is-active">登录</router-link>
        <!-- 注册链接：只在用户未认证时显示 -->
        <router-link to="/register" class="navbar-item" active-class="is-active">注册</router-link>
      </template>
    </div>
  </nav>
</template>

<style scoped>
.navbar {
  background-color: #343a40;
  padding: 0.8rem 1.5rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  color: #f8f9fa;
  position: sticky;
  top: 0;
  z-index: 1000;
  width: 100%;
  box-sizing: border-box;
}

.navbar-brand {
  display: flex;
  align-items: center;
}

.navbar-logo {
  font-size: 1.5rem;
  font-weight: bold;
  color: #ffffff;
  text-decoration: none;
  margin-right: 1rem;
}

.navbar-logo:hover {
  color: #e9ecef;
}

.navbar-menu {
  display: flex;
  align-items: center;
  flex-grow: 1;
}

.navbar-item {
  color: #e9ecef;
  text-decoration: none;
  padding: 0.5rem 1rem;
  margin: 0 0.25rem;
  border-radius: 4px;
  transition: background-color 0.2s, color 0.2s;
  white-space: nowrap;
}

.navbar-item:hover,
.navbar-item.is-active {
  background-color: #495057;
  color: #ffffff;
}

.navbar-end {
  margin-left: auto;
  display: flex;
  align-items: center;
}

.user-info {
  padding-right: 1rem;
  color: #adb5bd;
}

.logout-button {
  background-color: #dc3545;
  color: white;
  border: none;
  cursor: pointer;
  padding: 0.5rem 1rem;
  border-radius: 4px;
  transition: background-color 0.2s;
}

.logout-button:hover {
  background-color: #c82333;
}
</style>