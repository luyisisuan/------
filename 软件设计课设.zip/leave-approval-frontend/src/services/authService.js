// src/services/authService.js
import api from './api'; // 确保导入配置好的 Axios 实例，其路径相对于当前文件

class AuthService {
  /**
   * 用户登录
   * @param {object} credentials - 包含 username 和 password 的对象
   * @returns {Promise<object>} - 登录成功后返回的 JWT 响应对象 (JwtResponse)
   */
  async login(credentials) {
    try {
      // 假设登录 API 是 POST /auth/login
      // api 实例来自 ./api.js
      const response = await api.post('/auth/login', credentials);
      return response.data; // 返回后端响应体，例如 JwtResponse
    } catch (error) {
      console.error('AuthService: Error during login:', error);
      // 将错误向上抛出，以便调用方（如 Pinia action）可以捕获和处理
      throw error;
    }
  }

  /**
   * 用户注册
   * @param {object} userData - 包含 username, email, password, fullName 的对象
   * @returns {Promise<object>} - 注册成功后返回的消息对象 (MessageResponse)
   */
  async register(userData) {
    try {
      // 假设注册 API 是 POST /auth/register
      const response = await api.post('/auth/register', userData);
      return response.data; // 返回后端响应体，例如 MessageResponse
    } catch (error) {
      console.error('AuthService: Error during registration:', error);
      throw error;
    }
  }

  // 如果需要，可以在这里添加其他与认证相关的 API 调用方法，例如：
  // async getCurrentUser() {
  //   try {
  //     const response = await api.get('/users/me'); // 假设有获取当前用户信息的API
  //     return response.data;
  //   } catch (error) {
  //     console.error('AuthService: Error fetching current user:', error);
  //     throw error;
  //   }
  // }

  // async logoutApi() {
  //   try {
  //     await api.post('/auth/logout'); // 假设后端有登出API
  //   } catch (error) {
  //     console.error('AuthService: Error calling logout API:', error);
  //     // 即使后端登出失败，前端也应该继续登出流程
  //     throw error; // 可以选择是否向上抛出
  //   }
  // }
}

// **关键：导出一个 AuthService 类的实例作为默认导出**
export default new AuthService();