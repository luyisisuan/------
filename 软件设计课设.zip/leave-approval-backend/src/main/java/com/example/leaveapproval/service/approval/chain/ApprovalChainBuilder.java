package com.example.leaveapproval.service.approval.chain;

import com.example.leaveapproval.model.LeaveRequest;
import com.example.leaveapproval.model.User;
import com.example.leaveapproval.model.Role; // 导入 Role 枚举
import com.example.leaveapproval.repository.UserRepository; // 导入 UserRepository
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.time.temporal.ChronoUnit; // 用于计算请假天数 (如果需要在审批链逻辑中使用)
import java.util.List; // 导入 List
import java.util.Optional; // 导入 Optional

/**
 * 构建审批链并确定初始审批人的组件。
 * 这是职责链模式的一部分，用于动态或静态地配置审批流程的起点。
 */
@Component // 标记为Spring组件，可被注入
public class ApprovalChainBuilder {

    private static final Logger logger = LoggerFactory.getLogger(ApprovalChainBuilder.class);

    // 注入审批链中的各个审批者节点
    private final Approver teamLeadApprover;
    private final Approver deptManagerApprover; // 虽然在这里可能不直接作为初始审批人，但在构建完整审批链时会用到
    private final Approver hrApprover;

    // 注入 UserRepository 用于查找用户（特别是根据角色）
    private final UserRepository userRepository;

    /**
     * 通过构造函数注入依赖。
     * 使用 @Qualifier 来区分不同实现的 Approver 接口的 bean。
     */
    @Autowired
    public ApprovalChainBuilder(
            @Qualifier("teamLeadApprover") Approver teamLeadApprover,
            @Qualifier("deptManagerApprover") Approver deptManagerApprover,
            @Qualifier("hrApprover") Approver hrApprover,
            UserRepository userRepository) {
        this.teamLeadApprover = teamLeadApprover;
        this.deptManagerApprover = deptManagerApprover;
        this.hrApprover = hrApprover;
        this.userRepository = userRepository;
    }

    /**
     * 构建标准的审批链结构。
     * 例如：TeamLead -> DeptManager -> HR。
     * 这个方法定义了审批的顺序，但不指定具体由哪个用户审批（由各个Approver的processRequest方法决定）。
     *
     * @return 构建好的审批链的头部（即TeamLeadApprover）。
     */
    public Approver buildStandardChain() {
        logger.debug("构建标准审批链结构: TeamLead -> DeptManager -> HR");
        // 设置链中节点的先后关系
        teamLeadApprover.setNext(deptManagerApprover);
        deptManagerApprover.setNext(hrApprover);
        hrApprover.setNext(null); // HR是审批链的最后一个环节
        return teamLeadApprover; // 返回链的起点
    }

    /**
     * 根据请假申请确定审批流程的第一个具体的审批人实体（基于角色优先级查找）。
     * <p>
     * 查找逻辑顺序：
     * 1. 查找系统中拥有 ROLE_TEAM_LEAD 角色的用户列表，取第一个作为初始审批人。
     * 2. 如果没有找到 ROLE_TEAM_LEAD 用户，则查找系统中拥有 ROLE_HR 角色的用户列表，取第一个作为初始审批人。
     * 3. 如果也没有找到 ROLE_HR 用户，则查找系统中拥有 ROLE_ADMIN 角色的用户列表，取第一个作为最终回退的初始审批人。
     * 4. 如果上述所有角色用户都找不到，则返回 null，表示无法确定初始审批人。
     * <p>
     * 请注意：这种实现只找到“一个”符合角色的用户。在实际系统中，可能需要更复杂的逻辑来选择具体的审批人（如根据部门、负载均衡等），或者将请求同时发送给同角色的多个人。
     *
     * @param leaveRequest 请假申请的详细信息 (可用于日志或未来更复杂的规则判断)。
     * @param applicant    请假申请的提交人 (可用于日志)。
     * @return 第一个负责审批的 {@link User} 实体；如果无法确定，则返回 {@code null}。
     */
    public User getInitialApproverUser(LeaveRequest leaveRequest, User applicant) {
        logger.info("为申请人 {} 的请假申请 (ID: {}, 类型: {}) 确定初始审批人 (基于角色查找)...",
                applicant != null ? applicant.getUsername() : "未知用户",
                leaveRequest != null ? leaveRequest.getId() : "未知ID",
                leaveRequest != null ? leaveRequest.getLeaveType() : "未知类型");

        User initialApprover = null; // 用于存储找到的初始审批人

        // --- 查找优先级 1: ROLE_TEAM_LEAD ---
        List<User> teamLeads = userRepository.findByRolesContaining(Role.ROLE_TEAM_LEAD);
        if (!teamLeads.isEmpty()) {
            // 如果找到至少一个 Team Lead，取列表中的第一个作为初始审批人
            initialApprover = teamLeads.get(0);
            logger.info("找到 ROLE_TEAM_LEAD 用户 {} (ID: {}) 作为初始审批人。",
                    initialApprover.getUsername(), initialApprover.getId());
            return initialApprover; // 找到Team Lead，直接返回
        } else {
            logger.warn("系统中未找到拥有 ROLE_TEAM_LEAD 角色的用户。");
        }

        // --- 查找优先级 2: ROLE_HR ---
        List<User> hrUsers = userRepository.findByRolesContaining(Role.ROLE_HR);
        if (!hrUsers.isEmpty()) {
            // 如果找到至少一个 HR，取列表中的第一个作为初始审批人
            initialApprover = hrUsers.get(0);
            logger.info("未找到 TEAM_LEAD，找到 ROLE_HR 用户 {} (ID: {}) 作为初始审批人。",
                    initialApprover.getUsername(), initialApprover.getId());
            return initialApprover; // 找到HR，直接返回
        } else {
            logger.warn("系统中未找到拥有 ROLE_HR 角色的用户。");
        }

        // --- 查找优先级 3: ROLE_ADMIN (最终回退) ---
        List<User> adminUsers = userRepository.findByRolesContaining(Role.ROLE_ADMIN);
        if (!adminUsers.isEmpty()) {
            // 如果找到至少一个 ADMIN，取列表中的第一个作为最终回退的初始审批人
            initialApprover = adminUsers.get(0);
            logger.warn("未找到 TEAM_LEAD 和 HR，找到 ROLE_ADMIN 用户 {} (ID: {}) 作为最终回退的初始审批人。",
                    initialApprover.getUsername(), initialApprover.getId());
            return initialApprover; // 找到ADMIN，直接返回
        } else {
            logger.error("严重错误：系统中未找到任何 TEAM_LEAD、HR 或 ADMIN 角色用户。无法确定初始审批人。");
        }

        // 如果上述所有优先级都找不到符合条件的用户
        return null; // 返回 null，调用此方法的Service层应处理这种情况，例如抛出异常
    }

    // 原来的 findFirstHRUser() 辅助方法不再需要，其逻辑已集成到 getInitialApproverUser 中

}