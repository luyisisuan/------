package com.example.leaveapproval.model;

public enum Role {
    ROLE_EMPLOYEE,     // 普通员工
    ROLE_TEAM_LEAD,    // 团队领导 (审批人)
    ROLE_DEPT_MANAGER, // 部门经理 (审批人)
    ROLE_HR,           // HR (审批人)
    ROLE_ADMIN         // 系统管理员 (管理用户和系统配置)
}