<script setup>
import { ref, onMounted, computed } from 'vue';
// 修改这里的导入路径
import adminUserService from '../services/adminUserService';

// 状态
const users = ref([]);
const paginationData = ref({
  content: [], totalPages: 0, totalElements: 0, number: 0, size: 10,
});
const isLoading = ref(false);
const error = ref(null);

// 可用的角色列表 (可以从后端获取，或前端定义)
// 确保这些值与后端 Role 枚举的字符串表示一致
const availableRoles = ref([
  { value: 'ROLE_EMPLOYEE', text: '员工' },
  { value: 'ROLE_TEAM_LEAD', text: '团队领导' },
  { value: 'ROLE_DEPT_MANAGER', text: '部门经理' },
  { value: 'ROLE_HR', text: 'HR' },
  { value: 'ROLE_ADMIN', text: '管理员' },
]);

// --- 用户列表相关 ---
const fetchUsers = async (page = 0, size = 10) => {
  isLoading.value = true;
  error.value = null;
  try {
    const responseData = await adminUserService.getAllUsers({ page, size, sort: 'id,asc' });
    users.value = responseData.content || [];
    paginationData.value = {
      content: responseData.content || [],
      totalPages: responseData.totalPages || 0,
      totalElements: responseData.totalElements || 0,
      number: responseData.number || 0,
      size: responseData.size || size,
    };
  } catch (err) {
    console.error('Failed to fetch users:', err);
    error.value = '加载用户列表失败。';
    users.value = [];
  } finally {
    isLoading.value = false;
  }
};

onMounted(() => {
  fetchUsers();
});

// --- 创建/编辑用户模态框相关 ---
const isUserModalVisible = ref(false);
const editingUser = ref(null); // 如果是编辑模式，这里存储被编辑的用户对象
const userForm = ref({ // 表单数据
  id: null,
  username: '',
  email: '',
  password: '', // 仅创建时需要，编辑时通常不直接显示或有单独修改密码流程
  confirmPassword: '', // 仅创建时
  fullName: '',
  department: '',
  managerId: null, // 将来可以添加选择上级的功能
  roles: [], // 存储选中的角色 value
  enabled: true,
});
const userFormClientErrors = ref({});
const userFormServerError = ref(null);
const isSubmittingUserForm = ref(false);

const openCreateUserModal = () => {
  editingUser.value = null;
  userForm.value = { // 重置表单
    id: null, username: '', email: '', password: '', confirmPassword: '',
    fullName: '', department: '', managerId: null, roles: ['ROLE_EMPLOYEE'], enabled: true,
  };
  userFormClientErrors.value = {};
  userFormServerError.value = null;
  isUserModalVisible.value = true;
};

const openEditUserModal = async (user) => {
  // 为了获取完整的用户信息（如果列表只显示部分），可以重新请求一次
  // 或者直接使用列表中的数据，如果足够
  isLoading.value = true; // 可以用一个模态框专用的loading
  try {
      const fullUserData = await adminUserService.getUserById(user.id); // 假设UserDto包含所有需要编辑的字段
      editingUser.value = { ...fullUserData }; // 深拷贝
      userForm.value = {
        id: fullUserData.id,
        username: fullUserData.username, // 用户名通常不允许修改
        email: fullUserData.email,
        password: '', // 编辑时不显示密码
        confirmPassword: '',
        fullName: fullUserData.fullName,
        department: fullUserData.department || '',
        managerId: fullUserData.managerId || null,
        roles: fullUserData.roles ? fullUserData.roles.map(role => (typeof role === 'string' ? role : role.name || role.value)) : [], // 确保是角色值数组
        enabled: fullUserData.enabled,
      };
      userFormClientErrors.value = {};
      userFormServerError.value = null;
      isUserModalVisible.value = true;
  } catch (err) {
      console.error("Failed to fetch user details for editing:", err);
      error.value = "获取用户详情失败。"; // 页面级错误
  } finally {
      isLoading.value = false;
  }
};


const closeUserModal = () => {
  isUserModalVisible.value = false;
  editingUser.value = null;
};

const handleUserFormSubmit = async () => {
  userFormClientErrors.value = {};
  userFormServerError.value = null;
  isSubmittingUserForm.value = true;

  // 客户端校验 (简化版，可以根据需要扩展)
  if (!userForm.value.username && !editingUser.value) clientErrors.value.username = '用户名不能为空。'; // 创建时校验
  if (!userForm.value.email) userFormClientErrors.value.email = '邮箱不能为空。';
  if (!userForm.value.fullName) userFormClientErrors.value.fullName = '姓名不能为空。';
  if (!editingUser.value && !userForm.value.password) userFormClientErrors.value.password = '创建用户时密码不能为空。';
  if (!editingUser.value && userForm.value.password !== userForm.value.confirmPassword) userFormClientErrors.value.confirmPassword = '两次密码不一致。';
  if (!userForm.value.roles || userForm.value.roles.length === 0) userFormClientErrors.value.roles = '至少选择一个角色。';


  if (Object.keys(userFormClientErrors.value).length > 0) {
    isSubmittingUserForm.value = false;
    return;
  }

  try {
    if (editingUser.value) { // 编辑模式
      // 准备更新数据，不包含密码（除非有单独的修改密码逻辑）
      const updateData = {
        fullName: userForm.value.fullName,
        email: userForm.value.email,
        department: userForm.value.department,
        managerId: userForm.value.managerId,
        roles: userForm.value.roles,
        enabled: userForm.value.enabled,
      };
      await adminUserService.updateUser(editingUser.value.id, updateData);
      alert('用户信息更新成功！');
    } else { // 创建模式
      const createData = {
        username: userForm.value.username,
        email: userForm.value.email,
        password: userForm.value.password,
        fullName: userForm.value.fullName,
        department: userForm.value.department,
        managerId: userForm.value.managerId,
        roles: userForm.value.roles,
        // enabled 字段通常在后端默认为 true，或者根据 UserCreateRequest DTO
      };
      await adminUserService.createUser(createData);
      alert('用户创建成功！');
    }
    closeUserModal();
    fetchUsers(paginationData.value.number, paginationData.value.size); // 刷新列表
  } catch (err) {
    console.error('Error submitting user form:', err);
    if (err.response && err.response.data && err.response.data.message) {
      userFormServerError.value = err.response.data.message;
    } else if (err.response && err.response.data && typeof err.response.data === 'object') {
        let msg = "操作失败: ";
        for (const key in err.response.data) {
            msg += `${key}: ${err.response.data[key]}; `;
        }
        userFormServerError.value = msg;
    }
    else {
      userFormServerError.value = '操作失败，请稍后再试。';
    }
  } finally {
    isSubmittingUserForm.value = false;
  }
};


// --- 删除用户相关 ---
const handleDeleteUser = async (userId, username) => {
  if (!confirm(`您确定要删除用户 "${username}" (ID: ${userId}) 吗？此操作无法撤销。`)) {
    return;
  }
  isLoading.value = true; // 可以用一个列表操作的 loading
  error.value = null;
  try {
    await adminUserService.deleteUser(userId);
    alert(`用户 "${username}" 已成功删除！`);
    fetchUsers(paginationData.value.number, paginationData.value.size); // 刷新列表
  } catch (err) {
    console.error(`Error deleting user ${userId}:`, err);
     if (err.response && err.response.data && err.response.data.message) {
      error.value = err.response.data.message;
    } else {
      error.value = '删除用户失败。';
    }
  } finally {
    isLoading.value = false;
  }
};

const formatRoles = (roles) => {
    if (!Array.isArray(roles)) return 'N/A';
    return roles.map(role => (typeof role === 'string' ? role.replace('ROLE_', '') : (role.name || '').replace('ROLE_', ''))).join(', ');
};


// TODO: 分页逻辑
const currentPage = computed(() => paginationData.value.number + 1);
const totalPages = computed(() => paginationData.value.totalPages);

const goToPage = (page) => {
    if (page >= 0 && page < totalPages.value) {
        fetchUsers(page, paginationData.value.size);
    }
};

</script>

<template>
  <div class="admin-users-container">
    <header class="page-header">
      <h1>用户管理</h1>
      <button @click="openCreateUserModal" class="btn btn-primary">创建新用户</button>
    </header>

    <div v-if="isLoading && !users.length" class="loading-spinner">正在加载用户列表...</div>
    <div v-else-if="error" class="alert alert-danger">{{ error }}</div>
    <div v-else-if="users.length > 0" class="users-table-container">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>用户名</th>
            <th>姓名</th>
            <th>邮箱</th>
            <th>部门</th>
            <th>角色</th>
            <th>状态</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="user in users" :key="user.id">
            <td>{{ user.id }}</td>
            <td>{{ user.username }}</td>
            <td>{{ user.fullName }}</td>
            <td>{{ user.email }}</td>
            <td>{{ user.department || '-' }}</td>
            <td>{{ formatRoles(user.roles) }}</td>
            <td>
              <span :class="user.enabled ? 'status-active' : 'status-inactive'">
                {{ user.enabled ? '启用' : '禁用' }}
              </span>
            </td>
            <td>
              <button @click="openEditUserModal(user)" class="btn btn-sm btn-edit">编辑</button>
              <button @click="handleDeleteUser(user.id, user.username)" class="btn btn-sm btn-delete" :disabled="isLoading">删除</button>
            </td>
          </tr>
        </tbody>
      </table>
      <!-- 分页控件 -->
      <div class="pagination-controls" v-if="totalPages > 1">
        <button @click="goToPage(paginationData.number - 1)" :disabled="paginationData.number === 0 || isLoading">上一页</button>
        <span>第 {{ currentPage }} 页 / 共 {{ totalPages }} 页 ({{ paginationData.totalElements }} 条)</span>
        <button @click="goToPage(paginationData.number + 1)" :disabled="currentPage >= totalPages || isLoading">下一页</button>
      </div>
    </div>
    <div v-else class="no-data">
      系统中没有用户数据。
    </div>

    <!-- 创建/编辑用户模态框 -->
    <div v-if="isUserModalVisible" class="modal-overlay" @click.self="closeUserModal">
      <div class="modal-content">
        <h3>{{ editingUser ? '编辑用户' : '创建新用户' }}</h3>
        <form @submit.prevent="handleUserFormSubmit">
          <!-- 用户名 (创建时可编辑，编辑时只读) -->
          <div class="form-group">
            <label for="form-username">用户名 <span v-if="!editingUser" class="required">*</span></label>
            <input type="text" id="form-username" v-model.trim="userForm.username" :disabled="!!editingUser" :class="{'is-invalid': userFormClientErrors.username}"/>
            <div v-if="userFormClientErrors.username" class="invalid-feedback">{{ userFormClientErrors.username }}</div>
          </div>

          <!-- 姓名 -->
          <div class="form-group">
            <label for="form-fullName">姓名 <span class="required">*</span></label>
            <input type="text" id="form-fullName" v-model.trim="userForm.fullName" :class="{'is-invalid': userFormClientErrors.fullName}"/>
            <div v-if="userFormClientErrors.fullName" class="invalid-feedback">{{ userFormClientErrors.fullName }}</div>
          </div>

          <!-- 邮箱 -->
          <div class="form-group">
            <label for="form-email">邮箱 <span class="required">*</span></label>
            <input type="email" id="form-email" v-model.trim="userForm.email" :class="{'is-invalid': userFormClientErrors.email}"/>
            <div v-if="userFormClientErrors.email" class="invalid-feedback">{{ userFormClientErrors.email }}</div>
          </div>

          <!-- 密码 (仅创建时) -->
          <div v-if="!editingUser" class="form-group">
            <label for="form-password">密码 <span class="required">*</span></label>
            <input type="password" id="form-password" v-model="userForm.password" :class="{'is-invalid': userFormClientErrors.password}"/>
            <div v-if="userFormClientErrors.password" class="invalid-feedback">{{ userFormClientErrors.password }}</div>
          </div>
          <div v-if="!editingUser" class="form-group">
            <label for="form-confirmPassword">确认密码 <span class="required">*</span></label>
            <input type="password" id="form-confirmPassword" v-model="userForm.confirmPassword" :class="{'is-invalid': userFormClientErrors.confirmPassword}"/>
            <div v-if="userFormClientErrors.confirmPassword" class="invalid-feedback">{{ userFormClientErrors.confirmPassword }}</div>
          </div>

          <!-- 部门 -->
          <div class="form-group">
            <label for="form-department">部门</label>
            <input type="text" id="form-department" v-model.trim="userForm.department" />
          </div>

          <!-- 角色选择 (多选) -->
          <div class="form-group">
            <label>角色 <span class="required">*</span></label>
            <div class="roles-checkbox-group" :class="{'is-invalid-group': userFormClientErrors.roles}">
              <label v-for="roleOption in availableRoles" :key="roleOption.value" class="role-checkbox">
                <input type="checkbox" :value="roleOption.value" v-model="userForm.roles" />
                {{ roleOption.text }}
              </label>
            </div>
            <div v-if="userFormClientErrors.roles" class="invalid-feedback">{{ userFormClientErrors.roles }}</div>
          </div>

          <!-- 启用状态 -->
          <div class="form-group">
             <label class="role-checkbox">
                <input type="checkbox" v-model="userForm.enabled" />
                启用账户
              </label>
          </div>

          <!-- 服务端错误提示 -->
          <div v-if="userFormServerError" class="alert alert-danger">{{ userFormServerError }}</div>

          <div class="modal-actions">
            <button type="submit" class="btn btn-primary" :disabled="isSubmittingUserForm">
              <span v-if="isSubmittingUserForm" class="spinner"></span>
              {{ editingUser ? '更新用户' : '创建用户' }}
            </button>
            <button type="button" @click="closeUserModal" class="btn btn-secondary" :disabled="isSubmittingUserForm">取消</button>
          </div>
        </form>
      </div>
    </div>

  </div>
</template>

<style scoped>
/* 页面整体容器 */
.admin-users-container {
  max-width: 1200px; /* 可以更宽一些以容纳表格 */
  margin: 2rem auto;
  padding: 2rem;
  background-color: #f9f9f9;
  border-radius: 8px;
}

/* 页面头部，包含标题和创建按钮 */
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid #e0e0e0;
}
.page-header h1 {
  font-size: 1.8rem;
  color: #333;
  margin: 0;
}

/* 通用按钮样式 */
.btn {
  padding: 0.5rem 1rem;
  border-radius: 5px;
  cursor: pointer;
  border: none;
  font-weight: 500;
  transition: background-color 0.2s, box-shadow 0.2s;
}
.btn-primary {
  background-color: #007bff;
  color: white;
}
.btn-primary:hover:not(:disabled) {
  background-color: #0056b3;
}
.btn-secondary {
  background-color: #6c757d;
  color: white;
}
 .btn-secondary:hover:not(:disabled) {
  background-color: #545b62;
}
.btn:disabled {
    opacity: 0.65;
    cursor: not-allowed;
}

/* 表格容器 */
.users-table-container {
    background-color: #fff;
    padding: 1.5rem;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.07);
}

/* 表格样式 */
table {
  width: 100%;
  border-collapse: collapse;
}
th, td {
  border: 1px solid #dee2e6;
  padding: 0.75rem;
  text-align: left;
  vertical-align: middle;
}
th {
  background-color: #f8f9fa;
  font-weight: 600;
}
tr:nth-child(even) {
  background-color: #f9f9f9;
}

/* 状态标签样式 */
.status-active { color: #28a745; font-weight: bold; }
.status-inactive { color: #dc3545; }

/* 操作按钮样式 */
.btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.875rem;
    margin-right: 0.5rem;
}
.btn-edit {
    background-color: #ffc107;
    color: #212529;
}
.btn-edit:hover {
    background-color: #e0a800;
}
.btn-delete {
    background-color: #dc3545;
    color: white;
}
.btn-delete:hover {
    background-color: #c82333;
}

/* 加载、错误、无数据提示 */
.loading-spinner, .error-message, .no-data, .alert {
  text-align: center;
  padding: 1.5rem;
  margin-top: 1rem;
  border-radius: 5px;
}
.alert-danger {
  color: #721c24;
  background-color: #f8d7da;
  border: 1px solid #f5c6cb;
}

/* 模态框样式 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.6);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1050; /* 高于 Navbar */
}
.modal-content {
  background-color: white;
  padding: 2rem;
  border-radius: 8px;
  box-shadow: 0 5px 15px rgba(0,0,0,0.3);
  width: 100%;
  max-width: 550px;
  max-height: 90vh; /* 限制最大高度 */
  overflow-y: auto; /* 内容过多时可滚动 */
}
.modal-content h3 {
  margin-top: 0;
  margin-bottom: 1.5rem;
  font-size: 1.5rem;
}
.form-group {
  margin-bottom: 1rem;
}
.form-group label {
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 500;
}
.form-group input[type="text"],
.form-group input[type="email"],
.form-group input[type="password"],
.form-group select {
  width: 100%;
  padding: 0.6rem;
  border: 1px solid #ced4da;
  border-radius: 4px;
  font-size: 0.95rem;
}
 .form-group .is-invalid, .roles-checkbox-group.is-invalid-group {
    border-color: #dc3545 !important; /* 确保覆盖默认边框 */
 }
 .roles-checkbox-group {
    border: 1px solid #ced4da;
    padding: 0.5rem;
    border-radius: 4px;
 }
 .roles-checkbox-group.is-invalid-group {
    border: 1px solid #dc3545;
 }
 .role-checkbox {
    display: inline-block; /* 或者 block，根据需要调整布局 */
    margin-right: 1rem;
    margin-bottom: 0.5rem;
    align-items: center;
 }
 .role-checkbox input[type="checkbox"] {
     margin-right: 0.4rem;
     vertical-align: middle;
 }

.invalid-feedback {
    display: block;
    width: 100%;
    margin-top: 0.25rem;
    font-size: 0.8em;
    color: #dc3545;
 }
 .required {
   color: #dc3545;
   margin-left: 2px;
 }

.modal-actions {
  margin-top: 2rem;
  text-align: right;
}
.modal-actions .btn {
  margin-left: 0.5rem;
}

.spinner {
  display: inline-block;
  width: 1em;
  height: 1em;
  margin-right: 0.5em;
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  border-top-color: #fff;
  animation: spin 0.8s linear infinite;
  vertical-align: middle;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* 分页控件样式 */
.pagination-controls {
  margin-top: 1.5rem;
  text-align: center;
}
.pagination-controls button {
  margin: 0 0.3rem;
  padding: 0.4rem 0.8rem;
  border: 1px solid #dee2e6;
  background-color: #fff;
  color: #007bff;
  cursor: pointer;
  border-radius: 4px;
}
.pagination-controls button:hover:not(:disabled) {
  background-color: #e9ecef;
}
.pagination-controls button:disabled {
  color: #6c757d;
  cursor: not-allowed;
}
.pagination-controls span {
  margin: 0 0.75rem;
  color: #495057;
}

</style>