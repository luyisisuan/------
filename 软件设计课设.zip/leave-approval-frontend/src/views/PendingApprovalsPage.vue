<script setup>
import { ref, onMounted, computed } from 'vue';
import { useRouter } from 'vue-router';       // ← 新增
import leaveService from '../services/leaveService';
import { useAuthStore } from '../stores/auth';

const router = useRouter();                   // ← 新增
const authStore = useAuthStore();

const pendingRequests = ref([]);
const paginationData = ref({
  content: [], totalPages: 0, totalElements: 0,
  number: 0, size: 10,
});
const isLoadingPage = ref(false);
const pageError = ref(null);

// 格式化请假类型
const formatLeaveType = (type) => {
  const types = {
    ANNUAL_LEAVE: '年假', SICK_LEAVE: '病假',
    PERSONAL_LEAVE: '事假', MATERNITY_LEAVE: '产假',
    PATERNITY_LEAVE: '陪产假', BEREAVEMENT_LEAVE: '丧假',
    UNPAID_LEAVE: '无薪假', OTHER: '其他',
  };
  return types[type] || type;
};

// 格式化请假状态
const formatLeaveStatus = (status) => {
  const statuses = {
    PENDING_APPROVAL: '待审批', APPROVED: '已批准',
    REJECTED: '已驳回', CANCELLED: '已取消',
    PROCESSING: '处理中',
  };
  return statuses[status] || status;
};

// 获取待我审批的请假申请列表
const fetchPendingApprovals = async (page = 0, size = 10) => {
  isLoadingPage.value = true;
  pageError.value = null;
  try {
    const data = await leaveService.getPendingMyApprovalRequests({
      page, size, sort: 'createdAt,asc'
    });
    pendingRequests.value = data.content || [];
    paginationData.value = {
      content: data.content || [],
      totalPages: data.totalPages || 0,
      totalElements: data.totalElements || 0,
      number: data.number || 0,
      size: data.size || size,
    };
  } catch (err) {
    console.error(err);
    pageError.value = err.response?.data?.message
      || err.message
      || '获取待审批列表失败，请稍后再试。';
    pendingRequests.value = [];
    paginationData.value.content = [];
  } finally {
    isLoadingPage.value = false;
  }
};

onMounted(() => {
  if (authStore.canApprove) {
    fetchPendingApprovals(paginationData.value.number, paginationData.value.size);
  } else {
    pageError.value = "您没有权限查看此页面。";
  }
});

// 审批操作
const selectedRequestForAction = ref(null);
const approvalAction = ref('');
const approvalComments = ref('');
const isActionModalVisible = ref(false);
const isSubmittingAction = ref(false);
const actionError = ref(null);

const openApprovalModal = (request, actionType) => {
  selectedRequestForAction.value = request;
  approvalAction.value = actionType;
  approvalComments.value = '';
  actionError.value = null;
  isActionModalVisible.value = true;
};

const closeApprovalModal = () => {
  isActionModalVisible.value = false;
  selectedRequestForAction.value = null;
  approvalComments.value = '';
  actionError.value = null;
};

const submitApprovalAction = async () => {
  if (!selectedRequestForAction.value || !approvalAction.value) return;
  isSubmittingAction.value = true;
  actionError.value = null;
  try {
    await leaveService.processApproval(selectedRequestForAction.value.id, {
      decision: approvalAction.value,
      comments: approvalComments.value.trim(),
    });
    alert(`请假申请 #${selectedRequestForAction.value.id} 已${approvalAction.value === 'APPROVED' ? '批准' : '驳回'}！`);
    closeApprovalModal();
    fetchPendingApprovals(paginationData.value.number, paginationData.value.size);
  } catch (err) {
    console.error(err);
    actionError.value = err.response?.data?.message
      || err.message
      || '审批操作失败，请稍后再试。';
  } finally {
    isSubmittingAction.value = false;
  }
};

// 分页
const currentPage = computed(() => paginationData.value.number + 1);
const totalPages = computed(() => paginationData.value.totalPages);

const goToPage = (pageNumber) => {
  if (pageNumber >= 0 && pageNumber < totalPages.value && !isLoadingPage.value) {
    fetchPendingApprovals(pageNumber, paginationData.value.size);
  }
};
</script>

<template>
  <div class="pending-approvals-container">
    <!-- 顶部：返回 + 标题 -->
    <div class="page-header">
      <button class="btn-back" @click="router.back()">← 返回</button>
      <h1>待我审批的请假申请</h1>
    </div>

    <div v-if="isLoadingPage && !pendingRequests.length" class="loading-spinner">
      正在加载列表...
    </div>
    <div v-else-if="pageError" class="alert alert-danger">{{ pageError }}</div>
    <div v-else-if="pendingRequests.length > 0" class="requests-card">
      <table class="requests-table">
        <thead>
          <tr>
            <th>ID</th><th>申请人</th><th>请假类型</th>
            <th>开始日期</th><th>结束日期</th><th>理由</th>
            <th>提交时间</th><th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="req in pendingRequests" :key="req.id">
            <td>{{ req.id }}</td>
            <td>{{ req.applicant?.fullName || req.applicant?.username || 'N/A' }}</td>
            <td>{{ formatLeaveType(req.leaveType) }}</td>
            <td>{{ req.startDate }}</td>
            <td>{{ req.endDate }}</td>
            <td class="reason-cell" :title="req.reason">{{ req.reason }}</td>
            <td>{{ req.createdAt ? new Date(req.createdAt).toLocaleString('zh-CN') : '-' }}</td>
            <td class="actions-cell">
              <button @click="openApprovalModal(req, 'APPROVED')"
                      class="btn btn-approve"
                      :disabled="isSubmittingAction || isLoadingPage">
                批准
              </button>
              <button @click="openApprovalModal(req, 'REJECTED')"
                      class="btn btn-reject"
                      :disabled="isSubmittingAction || isLoadingPage">
                驳回
              </button>
              <router-link :to="{ name: 'LeaveDetails', params: { id: req.id } }"
                           class="action-link">
                查看详情
              </router-link>
            </td>
          </tr>
        </tbody>
      </table>

      <div class="pagination-controls" v-if="totalPages > 1">
        <button @click="goToPage(paginationData.number - 1)"
                :disabled="paginationData.number === 0 || isLoadingPage">
          上一页
        </button>
        <span>第 {{ currentPage }} 页 / 共 {{ totalPages }} 页 (共 {{ paginationData.totalElements }} 条)</span>
        <button @click="goToPage(paginationData.number + 1)"
                :disabled="currentPage >= totalPages || isLoadingPage">
          下一页
        </button>
      </div>
    </div>

    <div v-else class="no-requests">
      目前没有需要您审批的请假申请。
    </div>

    <!-- 审批模态框 -->
    <div v-if="isActionModalVisible" class="modal-overlay" @click.self="closeApprovalModal">
      <div class="modal-content">
        <h3>
          审批请假申请 #{{ selectedRequestForAction.id }} -
          <span :class="approvalAction === 'APPROVED' ? 'text-success' : 'text-danger'">
            {{ approvalAction === 'APPROVED' ? '批准' : '驳回' }}
          </span>
        </h3>
        <form @submit.prevent="submitApprovalAction">
          <div class="form-group">
            <label for="approvalComments">审批意见 (可选)：</label>
            <textarea id="approvalComments"
                      v-model="approvalComments"
                      rows="4"
                      placeholder="请输入您的审批意见..."></textarea>
          </div>
          <div v-if="actionError" class="alert alert-danger modal-error">{{ actionError }}</div>
          <div class="modal-actions">
            <button type="submit"
                    class="btn btn-primary"
                    :disabled="isSubmittingAction">
              <span v-if="isSubmittingAction" class="spinner"></span>
              确认{{ approvalAction === 'APPROVED' ? '批准' : '驳回' }}
            </button>
            <button type="button"
                    class="btn btn-secondary"
                    @click="closeApprovalModal"
                    :disabled="isSubmittingAction">
              取消
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<style scoped>
.pending-approvals-container {
  max-width: 1100px;
  margin: 2rem auto;
  padding: 2rem;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

/* 新增：页头 */
.page-header {
  display: flex;
  align-items: center;
  margin-bottom: 1.5rem;
}
.page-header h1 {
  flex: 1;
  text-align: center;
  color: #343a40;
  font-size: 1.6rem;
  margin: 0;
}
.btn-back {
  padding: 0.4rem 0.8rem;
  font-size: 0.9rem;
  border: 1px solid #ced4da;
  background: #fff;
  color: #495057;
  border-radius: 4px;
  cursor: pointer;
  transition: background .2s, box-shadow .2s;
}
.btn-back:hover {
  background: #e9ecef;
  box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

/* 表格卡片风格 */
.requests-card {
  background: #fafafa;
  padding: 1rem;
  border-radius: 6px;
  box-shadow: 0 1px 6px rgba(0,0,0,0.05);
}
.requests-table {
  width: 100%;
  border-collapse: collapse;
}
.requests-table th,
.requests-table td {
  border-bottom: 1px solid #e0e0e0;
  padding: 0.8rem 1rem;
}
.requests-table th {
  background: #f8f9fa;
  color: #495057;
  font-weight: 600;
}
.reason-cell {
  max-width: 200px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* 按钮 & 链接 */
.btn {
  padding: 0.4rem 0.8rem;
  border-radius: 4px;
  border: none;
  cursor: pointer;
  font-size: 0.9rem;
  transition: background .2s;
}
.btn-approve {
  background: #28a745; color: #fff;
}
.btn-approve:hover:not(:disabled) {
  background: #218838;
}
.btn-reject {
  background: #dc3545; color: #fff;
}
.btn-reject:hover:not(:disabled) {
  background: #c82333;
}
.action-link {
  margin-left: 0.5rem;
  color: #007bff;
  text-decoration: underline;
}
.action-link:hover {
  color: #0056b3;
}

/* 分页 */
.pagination-controls {
  margin-top: 1.5rem;
  text-align: center;
}
.pagination-controls button {
  margin: 0 0.3rem;
  padding: 0.5rem 1rem;
  border: 1px solid #dee2e6;
  background: #fff;
  color: #007bff;
  border-radius: 4px;
  cursor: pointer;
}
.pagination-controls button:hover:not(:disabled) {
  background: #e9ecef;
}
.pagination-controls button:disabled {
  color: #6c757d;
  cursor: not-allowed;
}

/* 加载 / 无请求 / 错误 */
.loading-spinner,
.no-requests,
.alert-danger {
  text-align: center;
  padding: 2rem;
  color: #6c757d;
}
.alert-danger {
  background: #f8d7da;
  color: #721c24;
  border-radius: 5px;
  margin-bottom: 1.5rem;
}

/* 模态框 */
.modal-overlay {
  position: fixed; inset: 0;
  background: rgba(0,0,0,0.6);
  display: flex; justify-content: center; align-items: center;
  z-index: 1050;
}
.modal-content {
  background: #fff;
  padding: 2rem;
  border-radius: 8px;
  width: 100%; max-width: 480px;
  box-shadow: 0 5px 20px rgba(0,0,0,0.1);
}
.modal-content h3 {
  margin-top: 0; margin-bottom: 1rem;
  color: #333;
}
.form-group label {
  display: block; margin-bottom: 0.5rem;
}
.form-group textarea {
  width: 100%; padding: 0.6rem;
  border: 1px solid #ccc; border-radius: 4px;
  resize: vertical;
}
.modal-actions {
  text-align: right; margin-top: 1.2rem;
}
.btn-primary {
  background: #007bff; color: #fff;
  margin-right: 0.5rem;
}
.btn-primary:hover:not(:disabled) {
  background: #0056b3;
}
.btn-secondary {
  background: #6c757d; color: #fff;
}
.btn-secondary:hover:not(:disabled) {
  background: #545b62;
}
.spinner {
  display: inline-block;
  width: 1em; height: 1em;
  border: 2px solid rgba(255,255,255,0.3);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
  margin-right: 0.3rem;
  vertical-align: middle;
}
@keyframes spin { to { transform: rotate(360deg); } }
</style>
