<script setup>
import { ref, onMounted, computed } from 'vue';
import leaveService from '../services/leaveService'; // 导入请假服务
// import { useAuthStore } from '../stores/auth'; // 如果需要 authStore 中的信息

// const authStore = useAuthStore();

// 存储请假申请列表
const myRequests = ref([]);
// 存储分页信息
const paginationData = ref({
  content: [],
  totalPages: 0,
  totalElements: 0,
  number: 0, // Spring Pageable 的页码从0开始
  size: 10, // 默认每页数量
});

// 页面状态控制
const isLoading = ref(false);
const error = ref(null);

// 格式化请假类型和状态的辅助函数
const formatLeaveType = (type) => {
  const types = {
    ANNUAL_LEAVE: '年假', SICK_LEAVE: '病假', PERSONAL_LEAVE: '事假', MATERNITY_LEAVE: '产假',
    PATERNITY_LEAVE: '陪产假', BEREAVEMENT_LEAVE: '丧假', UNPAID_LEAVE: '无薪假', OTHER: '其他',
  };
  return types[type] || type;
};

const formatLeaveStatus = (status) => {
  const statuses = {
    PENDING_APPROVAL: '待审批', APPROVED: '已批准', REJECTED: '已驳回',
    CANCELLED: '已取消', PROCESSING: '处理中',
  };
  return statuses[status] || status;
};

// 获取当前用户提交的请假申请列表
const fetchMyRequests = async (page = 0, size = 10) => {
  isLoading.value = true;
  error.value = null;
  try {
    const responseData = await leaveService.getMyLeaveRequests({
      page: page,
      size: size,
      sort: 'createdAt,desc' // 按创建时间降序排列
    });
    myRequests.value = responseData.content || [];
    paginationData.value = {
      content: responseData.content || [],
      totalPages: responseData.totalPages || 0,
      totalElements: responseData.totalElements || 0,
      number: responseData.number || 0,
      size: responseData.size || size,
    };
  } catch (err) {
    console.error('MyRequestsPage: 获取我的申请列表失败:', err);
    if (err.response && err.response.data && err.response.data.message) {
      error.value = err.response.data.message;
    } else if (err.message) {
      error.value = err.message;
    } else {
      error.value = '获取申请列表失败，请稍后再试或联系管理员。';
    }
    myRequests.value = [];
    paginationData.value.content = [];
  } finally {
    isLoading.value = false;
  }
};

onMounted(() => {
  fetchMyRequests(paginationData.value.number, paginationData.value.size);
});

// 判断是否可以取消申请
const canCancelRequest = (status) => {
  return status === 'PENDING_APPROVAL'; // 只有待审批状态的可以取消
};

// 处理取消申请的逻辑
const handleCancelRequest = async (requestId) => {
  if (!confirm(`您确定要取消ID为 ${requestId} 的请假申请吗？`)) {
    return;
  }
  // 可以为取消操作设置一个单独的 loading 状态，或者共用页面的 isLoading
  // const cancellingId = ref(null);
  // cancellingId.value = requestId;
  isLoading.value = true; // 简单共用
  try {
    await leaveService.cancelLeaveRequest(requestId);
    alert('请假申请已成功取消！');
    // 取消成功后重新加载列表
    fetchMyRequests(paginationData.value.number, paginationData.value.size);
  } catch (err) {
    console.error(`MyRequestsPage: 取消请假申请 ID ${requestId} 失败:`, err);
    let cancelError = '取消申请失败。';
    if (err.response && err.response.data && err.response.data.message) {
      cancelError = err.response.data.message;
    } else if (err.message) {
      cancelError = err.message;
    }
    alert(cancelError);
  } finally {
    isLoading.value = false;
    // cancellingId.value = null;
  }
};

// 分页逻辑 (简单实现)
const goToPage = (pageNumber) => {
  if (pageNumber >= 0 && pageNumber < paginationData.value.totalPages && !isLoading.value) {
    fetchMyRequests(pageNumber, paginationData.value.size);
  }
};
const currentPage = computed(() => paginationData.value.number + 1);
const totalPages = computed(() => paginationData.value.totalPages);

</script>

<template>
  <div class="my-requests-container">
    <h1>我的请假申请</h1>

    <div v-if="isLoading && !myRequests.length" class="loading-spinner">正在加载申请列表...</div>
    <div v-else-if="error" class="alert alert-danger">{{ error }}</div>
    <div v-else-if="myRequests.length > 0" class="requests-list">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>请假类型</th>
            <th>开始日期</th>
            <th>结束日期</th>
            <th>理由</th>
            <th>当前状态</th>
            <th>提交时间</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="request in myRequests" :key="request.id">
            <td>{{ request.id }}</td>
            <td>{{ formatLeaveType(request.leaveType) }}</td>
            <td>{{ request.startDate }}</td>
            <td>{{ request.endDate }}</td>
            <td class="reason-cell" :title="request.reason">{{ request.reason }}</td>
            <td>
              <span :class="`status-${request.status.toLowerCase()}`">
                {{ formatLeaveStatus(request.status) }}
              </span>
            </td>
            <td>{{ request.createdAt ? new Date(request.createdAt).toLocaleString() : '-' }}</td>
            <td class="actions-cell">
              <!-- 查看详情链接 -->
              <router-link
                :to="{ name: 'LeaveDetails', params: { id: request.id } }"
                class="action-link view-details"
              >
                查看详情
              </router-link>
              <!-- 取消按钮 -->
              <button
                v-if="canCancelRequest(request.status)"
                @click="handleCancelRequest(request.id)"
                class="btn btn-cancel"
                :disabled="isLoading"
              >
                取消
              </button>
            </td>
          </tr>
        </tbody>
      </table>

      <!-- 分页控件 -->
      <div class="pagination-controls" v-if="totalPages > 1">
        <button @click="goToPage(paginationData.number - 1)" :disabled="paginationData.number === 0 || isLoading">
          上一页
        </button>
        <span>第 {{ currentPage }} 页 / 共 {{ totalPages }} 页 (总计: {{ paginationData.totalElements }} 条)</span>
        <button @click="goToPage(paginationData.number + 1)" :disabled="currentPage >= totalPages || isLoading">
          下一页
        </button>
      </div>

    </div>
    <div v-else class="no-requests">
      您还没有提交过任何请假申请。
      <router-link to="/submit-leave" class="action-link">立即提交一个？</router-link>
    </div>
  </div>
</template>

<style scoped>
.my-requests-container {
  max-width: 1100px;
  margin: 2rem auto;
  padding: 2rem;
  background-color: #ffffff;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.07);
}
.my-requests-container h1 {
  text-align: center;
  margin-bottom: 2.5rem;
  color: #343a40;
  font-weight: 600;
  font-size: 2rem;
}
.loading-spinner, .error-message, .no-requests {
  text-align: center;
  padding: 2rem;
  font-size: 1.1rem;
  color: #6c757d;
}
.alert-danger {
  color: #721c24;
  background-color: #f8d7da;
  border: 1px solid #f5c6cb;
  border-radius: 5px;
  margin-bottom: 1.5rem;
}
.requests-list table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 1rem;
}
.requests-list th, .requests-list td {
  border: 1px solid #e0e0e0;
  padding: 0.8rem 1rem;
  text-align: left;
  vertical-align: middle;
}
.requests-list th {
  background-color: #f8f9fa;
  font-weight: 600;
  color: #495057;
}
.requests-list tr:nth-child(even) {
  background-color: #fdfdfd;
}
.requests-list tr:hover {
  background-color: #f1f3f5;
}
.reason-cell {
  max-width: 250px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  cursor: help;
}

.status-pending_approval { color: #ffc107; font-weight: bold; }
.status-approved { color: #28a745; font-weight: bold; }
.status-rejected { color: #dc3545; font-weight: bold; }
.status-cancelled { color: #6c757d; text-decoration: line-through; }
.status-processing { color: #17a2b8; font-weight: bold; }

.actions-cell {
  white-space: nowrap; /* 防止操作按钮换行 */
}
.action-link, .btn {
  text-decoration: none;
  cursor: pointer;
  padding: 0.3rem 0.6rem;
  border-radius: 4px;
  transition: background-color 0.2s, color 0.2s, border-color 0.2s;
  margin-right: 0.5rem; /* 给操作按钮之间一些间距 */
  border: 1px solid transparent;
  font-size: 0.85rem; /* 统一操作区域字体大小 */
}
.action-link:last-child, .btn:last-child {
  margin-right: 0;
}
.action-link.view-details { /* 查看详情链接特定样式 */
  color: #007bff;
  background-color: transparent;
  border-color: #007bff;
}
.action-link.view-details:hover {
  background-color: #007bff;
  color: white;
  text-decoration: none;
}

.btn-cancel {
  background-color: #ffc107;
  color: #212529;
  border-color: #ffc107;
}
.btn-cancel:hover {
  background-color: #e0a800;
  border-color: #d39e00;
}
.btn-cancel:disabled {
  background-color: #6c757d;
  cursor: not-allowed;
  opacity: 0.65;
}

.pagination-controls {
  margin-top: 2rem;
  text-align: center;
}
.pagination-controls button {
  margin: 0 0.5rem;
  padding: 0.5rem 1rem;
  border: 1px solid #dee2e6;
  background-color: #fff;
  color: #007bff;
  cursor: pointer;
  border-radius: 4px;
  transition: background-color 0.15s ease-in-out;
}
.pagination-controls button:hover:not(:disabled) {
  background-color: #e9ecef;
}
.pagination-controls button:disabled {
  color: #6c757d;
  cursor: not-allowed;
  opacity: 0.65;
}
.pagination-controls span {
  margin: 0 1rem;
  color: #495057;
  vertical-align: middle;
}

.no-requests {
  border: 1px dashed #ced4da;
  padding: 3rem;
  border-radius: 8px;
  background-color: #f8f9fa;
}
.no-requests .action-link {
  display: inline-block;
  margin-top: 1rem;
  padding: 0.6rem 1.2rem;
  background-color: #007bff;
  color: white;
  border-radius: 5px;
}
.no-requests .action-link:hover {
  background-color: #0056b3;
  text-decoration: none;
}

</style>