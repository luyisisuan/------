<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
// 导入请假服务，用于调用后端API
import leaveService from '../services/leaveService';
// 如果 SubmitLeavePage 不需要直接访问 authStore 的状态（例如用户ID），可以不导入以减少耦合
// import { useAuthStore } from '../stores/auth';

const router = useRouter();
// 获取 authStore 实例（如果需要访问用户角色或其他状态）
// const authStore = useAuthStore();

// 请假表单数据，使用 ref 创建响应式引用
const leaveType = ref('');
const startDate = ref('');
const endDate = ref('');
const reason = ref('');
// attachments (附件，如果需要实现上传功能，这里是占位符)

// 页面和表单的状态控制
const isLoading = ref(false);      // 表示正在提交申请的加载状态
const clientErrors = ref({});    // 存储客户端校验失败的错误信息
const serverError = ref(null);   // 存储从服务端返回的错误信息
const submitSuccess = ref(false); // 表示请假申请是否已成功提交

/**
 * 处理请假申请表单的提交事件
 */
const handleSubmit = async () => {
  // 1. 在每次提交前，清空之前的错误提示和状态
  clientErrors.value = {}; // 清空客户端错误
  serverError.value = null; // 清空服务端错误
  submitSuccess.value = false; // 重置成功状态

  // 客户端表单字段校验：检查必填项是否为空或不符合基本格式
  if (!leaveType.value) {
    clientErrors.value.leaveType = '请选择请假类型。';
  }
  if (!startDate.value) {
    clientErrors.value.startDate = '请选择开始日期。';
  }
  if (!endDate.value) {
    clientErrors.value.endDate = '请选择结束日期。';
  }
  if (!reason.value.trim()) {
    clientErrors.value.reason = '请填写请假理由。';
  }

  // 日期逻辑校验：确保结束日期不早于开始日期，开始日期不早于今天
  if (startDate.value && endDate.value) {
      const start = new Date(startDate.value);
      const end = new Date(endDate.value);

      // 校验结束日期是否早于开始日期
       if (start > end) {
         clientErrors.value.dateRange = '结束日期不能早于开始日期。';
       }

       // 校验开始日期是否早于今天
       const today = new Date();
       today.setHours(0,0,0,0); // 重置时间部分，只比较日期
       if (start < today) {
           // 如果已经有日期范围错误，追加提示；否则直接设置错误
           clientErrors.value.dateRange = clientErrors.value.dateRange
               ? clientErrors.value.dateRange + ' 且请假开始日期不能早于今天。'
               : '请假开始日期不能早于今天。';
           // 也可以选择为 startDate 设置独立的错误提示，根据UI设计决定
           // clientErrors.value.startDate = '请假开始日期不能早于今天。';
       }
  } else if (startDate.value) { // 如果只填写了开始日期，也要校验不能早于今天
       const start = new Date(startDate.value);
       const today = new Date();
       today.setHours(0,0,0,0);
       if (start < today) {
            clientErrors.value.startDate = '请假开始日期不能早于今天。';
       }
  }


  // 如果存在任何客户端校验错误，则停止后续提交流程
  if (Object.keys(clientErrors.value).length > 0) {
    console.log('SubmitLeavePage: 客户端校验失败，停止提交。', clientErrors.value);
    return;
  }

  // 如果客户端校验通过，则尝试提交到后端
   console.log('SubmitLeavePage: 客户端校验通过，尝试提交请假申请。');

  isLoading.value = true; // 设置加载状态为 true，禁用提交按钮

  try {
    // 2. 构建发送到后端的请求数据 DTO
    // 注意：后端的 startDate 和 endDate 是 LocalDate 类型，前端传递 YYYY-MM-DD 格式字符串即可，Axios会正确处理
    const requestData = {
      leaveType: leaveType.value, // 请假类型枚举名字符串 (如 'ANNUAL_LEAVE')
      startDate: startDate.value, // 日期字符串 (如 '2023-12-25')
      endDate: endDate.value,     // 日期字符串
      reason: reason.value.trim(), // 移除理由首尾空白
      // attachments... // 如果有附件上传功能，需要在这里处理文件或标识符
    };

    // 3. **调用真实的后端 API**
    // 使用 leaveService 封装的 Axios 实例发送 POST 请求到 /api/leave-requests
    // api 实例的请求拦截器会自动为需要认证的请求添加 JWT Token
    const submittedLeaveRequest = await leaveService.submitLeave(requestData);

    // 4. 处理成功响应 (假设后端返回 LeaveRequestViewDto 和 201 Created 状态码)
    console.log('SubmitLeavePage: 请假申请提交成功:', submittedLeaveRequest);
    submitSuccess.value = true; // 设置提交成功状态为 true，显示成功提示

    // 可以在提交成功后根据需要执行一些操作，例如：
    // - 清空表单字段 (如果希望保留成功提示但允许再次提交)
    // resetFormFields(); // 调用本地方法清空字段
    // - 弹出一个额外的成功提示框 (除了模板中的提示框外)
    // - 延迟几秒后自动跳转到“我的申请”页面，方便用户查看状态
    // setTimeout(() => {
    //    router.push('/my-requests');
    // }, 3000);


  } catch (error) {
    // 5. 处理失败响应 (API 请求失败，如非 2xx 状态码或网络错误)
    console.error('SubmitLeavePage: 提交请假申请失败:', error);
    // 假设后端的错误响应体结构如下 (对应 GlobalExceptionHandler 的返回):
    // 通用错误：{ message: "具体的错误信息" } 或简单的字符串错误
    // 字段校验错误 (MethodArgumentNotValidException)：可能是一个对象，key是字段名，value是错误信息字符串或数组
    // 这里尝试提取错误信息进行显示
    if (error.response && error.response.data) {
        const errorData = error.response.data;
        if (errorData.message) {
            // 后端返回通用错误信息 (如 Service 层抛出的业务异常)
            serverError.value = errorData.message;
        } else if (typeof errorData === 'object') {
             // 尝试解析后端返回的字段级别校验错误或其他结构化错误
             let errorMessage = '提交失败：';
             let hasFieldErrors = false;
             for (const field in errorData) {
                 // 拼接所有字段的错误信息
                 if (Array.isArray(errorData[field])) {
                     errorMessage += `${field}: ${errorData[field].join(', ')}; `;
                     hasFieldErrors = true;
                 } else if (typeof errorData[field] === 'string') {
                     errorMessage += `${field}: ${errorData[field]}; `;
                     hasFieldErrors = true;
                 }
             }
             if (hasFieldErrors) {
                 serverError.value = errorMessage; // 显示拼接后的字段错误信息
             } else {
                // 如果错误体是对象但没有预期的字段错误结构，显示通用错误
                serverError.value = '提交请假申请时发生未知校验错误。';
                console.warn('SubmitLeavePage: 未按预期解析后端错误体结构:', errorData);
             }
        } else {
            // 其他未知格式的错误体，显示原始错误体（如果不是对象的话）或通用提示
             serverError.value = `提交请假申请时收到未知响应: ${JSON.stringify(errorData)}`;
             console.warn('SubmitLeavePage: 收到未知格式的后端错误体:', errorData);
        }
    } else {
        // 处理非 HTTP 错误，例如网络连接中断或服务器无响应
        serverError.value = '网络或服务器连接失败。请检查网络或稍后再试。';
         console.error('SubmitLeavePage: 非 HTTP 错误:', error);
    }

  } finally {
    // 提交过程结束，无论成功或失败，都设置加载状态为 false
    isLoading.value = false;
  }
};

/**
 * 清空所有表单字段和客户端错误提示
 */
const resetFormFields = () => {
    leaveType.value = '';
    startDate.value = '';
    endDate.value = '';
    reason.value = '';
    clientErrors.value = {}; // 清空客户端错误
};

/**
 * 重置整个表单状态，包括字段、客户端错误、服务端错误和成功状态
 * 通常在提交成功后点击“提交新的申请”按钮时调用
 */
const resetForm = () => {
    resetFormFields(); // 清空字段和客户端错误
    serverError.value = null; // 清空服务端错误提示
    submitSuccess.value = false; // 清空成功状态，隐藏成功提示
    console.log('SubmitLeavePage: 表单已重置。');
};


// 可用的请假类型，可以从后端获取，目前先前端定义
// 未来可以调用一个 leaveService.getLeaveTypes() API 来获取
const leaveTypes = ref([
    { value: 'ANNUAL_LEAVE', text: '年假' },
    { value: 'SICK_LEAVE', text: '病假' },
    { value: 'PERSONAL_LEAVE', text: '事假' },
    { value: 'MATERNITY_LEAVE', text: '产假' },
    { value: 'PATERNITY_LEAVE', text: '陪产假' },
    { value: 'BEREAVEMENT_LEAVE', text: '丧假' },
    { value: 'UNPAID_LEAVE', text: '无薪假' },
    { value: 'OTHER', text: '其他' },
]);

// 如果需要，可以在组件挂载时获取请假类型列表
// onMounted(async () => {
//   try {
//     const types = await leaveService.getLeaveTypes(); // 假设有这个 API
//     leaveTypes.value = types; // 更新请假类型列表
//   } catch (error) {
//     console.error('Failed to fetch leave types:', error);
//     // 可以设置一个错误提示
//   }
// });

</script>

<template>
  <div class="submit-leave-container">
    <div class="leave-form-card">
      <h2>提交请假申请</h2>
      <!-- 使用 @submit.prevent 阻止表单默认提交行为，改由 handleSubmit 方法处理 -->
      <form @submit.prevent="handleSubmit">

        <!-- 请假类型选择组 -->
        <div class="form-group">
          <label for="leaveType">请假类型 <span class="required">*</span></label>
          <select id="leaveType" v-model="leaveType" :class="{'is-invalid': clientErrors.leaveType}">
            <option value="" disabled>请选择</option>
            <!-- 循环渲染请假类型选项，key和value绑定到type.value -->
            <option v-for="type in leaveTypes" :key="type.value" :value="type.value">{{ type.text }}</option>
          </select>
          <!-- 显示请假类型相关的客户端校验错误 -->
          <div v-if="clientErrors.leaveType" class="invalid-feedback">{{ clientErrors.leaveType }}</div>
        </div>

        <!-- 开始日期输入组 -->
        <div class="form-group">
          <label for="startDate">开始日期 <span class="required">*</span></label>
          <input
            type="date"
            id="startDate"
            v-model="startDate"
            :class="{'is-invalid': clientErrors.startDate || clientErrors.dateRange}"
          />
          <!-- 显示开始日期相关的客户端校验错误 -->
          <div v-if="clientErrors.startDate" class="invalid-feedback">{{ clientErrors.startDate }}</div>
          <!-- 显示日期范围校验错误，仅当没有特定的开始日期错误时 -->
          <div v-if="clientErrors.dateRange && !clientErrors.startDate" class="invalid-feedback">{{ clientErrors.dateRange }}</div>
        </div>

        <!-- 结束日期输入组 -->
        <div class="form-group">
          <label for="endDate">结束日期 <span class="required">*</span></label>
          <input
            type="date"
            id="endDate"
            v-model="endDate"
            :class="{'is-invalid': clientErrors.endDate || clientErrors.dateRange}"
          />
          <!-- 显示结束日期相关的客户端校验错误 -->
          <div v-if="clientErrors.endDate" class="invalid-feedback">{{ clientErrors.endDate }}</div>
          <!-- 显示日期范围校验错误，仅当没有特定的开始日期错误和结束日期错误时 -->
           <div v-if="clientErrors.dateRange && !clientErrors.endDate && !clientErrors.startDate" class="invalid-feedback">{{ clientErrors.dateRange }}</div>
        </div>

        <!-- 请假理由输入组 -->
        <div class="form-group">
          <label for="reason">请假理由 <span class="required">*</span></label>
          <textarea
            id="reason"
            v-model.trim="reason"
            rows="4"
            :class="{'is-invalid': clientErrors.reason}"
            placeholder="请详细描述请假原因"
          ></textarea>
           <!-- 显示请假理由相关的客户端校验错误 -->
           <div v-if="clientErrors.reason" class="invalid-feedback">{{ clientErrors.reason }}</div>
        </div>

        <!-- 附件上传 (可选实现，目前注释掉) -->
        <!--
        <div class="form-group">
          <label for="attachments">附件</label>
          <input type="file" id="attachments" @change="handleFileUpload">
        </div>
        -->

        <!-- 显示服务端错误信息 -->
        <!-- 仅在有 serverError 且没有提交成功时显示 -->
        <div v-if="serverError && !submitSuccess" class="alert alert-danger" role="alert">
          {{ serverError }}
        </div>

         <!-- 显示提交成功信息 -->
         <!-- 仅在 submitSuccess 为 true 时显示 -->
         <div v-if="submitSuccess" class="alert alert-success" role="alert">
           请假申请已提交，请等待审批。您可以在“我的申请”中查看进度。
         </div>

        <!-- 提交按钮 -->
        <!-- 禁用状态绑定到 isLoading 或 submitSuccess -->
        <button type="submit" :disabled="isLoading || submitSuccess" class="submit-button">
          <!-- 加载中图标和文字 -->
          <span v-if="isLoading" class="spinner"></span>
          <span v-if="isLoading">提交中...</span>
          <!-- 正常文字 -->
          <span v-else>提交申请</span>
        </button>

         <!-- 提交成功后显示“提交新的申请”按钮 -->
         <button v-if="submitSuccess" type="button" @click="resetForm" class="btn btn-secondary mt-3">
           提交新的申请
         </button>

      </form>
    </div>
  </div>
</template>

<style scoped>
/* 样式代码，复用或修改自 LoginPage 的样式 */
/* 页面容器样式 */
.submit-leave-container {
  display: flex;
  justify-content: center; /* 水平居中 */
  padding: 2rem; /* 内边距 */
  background-color: #f8f9fa; /* 页面背景色 */
}

/* 表单卡片样式 */
.leave-form-card {
  background: #ffffff; /* 背景白色 */
  padding: 2.5rem 3rem; /* 内边距 */
  border-radius: 10px; /* 圆角 */
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1); /* 阴影 */
  width: 100%; /* 宽度 */
  max-width: 600px; /* 最大宽度 */
  border-top: 5px solid #28a745; /* 顶部装饰线，提交页面用绿色系 */
}

/* 表单标题样式 */
.leave-form-card h2 {
  text-align: center;
  margin-bottom: 2rem;
  color: #343a40;
  font-size: 1.8rem;
  font-weight: 600;
}

/* 表单组样式 */
.form-group {
  margin-bottom: 1.5rem;
}

/* Label 样式 */
.form-group label {
  display: block;
  margin-bottom: 0.6rem;
  font-weight: 500;
  color: #495057;
}

/* 输入框、选择框、文本域样式 */
.form-group input[type="text"],
.form-group input[type="date"],
.form-group select,
.form-group textarea {
  width: 100%;
  padding: 0.85rem 1rem;
  border: 1px solid #ced4da;
  border-radius: 5px;
  font-size: 1rem;
  color: #495057;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}

/* 文本域允许垂直调整大小 */
 .form-group textarea {
   resize: vertical;
 }

/* 输入框、选择框、文本域获取焦点时的样式 */
.form-group input:focus,
.form-group select:focus,
 .form-group textarea:focus {
  border-color: #80bdff;
  outline: 0;
  box-shadow: 0 0 0 0.25rem rgba(0, 123, 255, 0.25);
}

/* 校验失败时输入框的边框样式 */
.form-group .is-invalid {
    border-color: #dc3545;
}

/* 校验失败时的提示文字样式 */
 .invalid-feedback {
    display: block; /* 确保独占一行 */
    width: 100%;
    margin-top: 0.25rem;
    font-size: 0.875em;
    color: #dc3545;
 }

/* 必填项标记 (*) 的样式 */
 .required {
   color: #dc3545;
   margin-left: 4px;
 }

/* 提交按钮样式 */
.submit-button {
  width: 100%;
  padding: 0.85rem;
  background-color: #28a745; /* 绿色系 */
  color: white;
  border: none;
  border-radius: 5px;
  font-size: 1.1rem;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.2s ease-in-out, transform 0.1s ease;
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
}

/* 提交按钮 Hover 时的样式 */
.submit-button:hover:not(:disabled) {
  background-color: #218838;
  transform: translateY(-1px);
}

/* 提交按钮 Active 时的样式 */
.submit-button:active:not(:disabled) {
  transform: translateY(0px);
}

/* 提交按钮禁用时的样式 */
.submit-button:disabled {
  background-color: #6c757d;
  cursor: not-allowed;
}

/* 加载中 spinner 样式 */
.spinner {
  display: inline-block;
  width: 1.2em;
  height: 1.2em;
  margin-right: 0.7em;
  border: 3px solid rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  border-top-color: #fff;
  animation: spin 0.8s linear infinite;
  vertical-align: middle;
}

/* spinner 旋转动画 */
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

/* Alert 样式 */
 .alert {
    padding: 1rem 1.25rem;
    margin-bottom: 1.5rem;
    border: 1px solid transparent;
    border-radius: 0.25rem;
 }

/* 错误 Alert 样式 */
 .alert-danger {
    color: #721c24;
    background-color: #f8d7da;
    border-color: #f5c6cb;
 }

/* 成功 Alert 样式 */
  .alert-success {
     color: #155724;
     background-color: #d4edda;
     border-color: #c3e6cb;
  }

/* 次级按钮样式 (用于“提交新的申请”) */
  .btn-secondary {
      background-color: #6c757d;
      color: white;
      border: none;
      border-radius: 5px;
      padding: 0.85rem;
      font-size: 1.1rem;
      font-weight: 500;
      cursor: pointer;
      transition: background-color 0.2s;
      width: 100%;
  }

  .btn-secondary:hover {
      background-color: #5a6268;
  }

/* 顶部外边距工具类 */
  .mt-3 {
      margin-top: 1rem;
  }

</style>