<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router'; // 引入 useRouter 用于编程式导航登录后跳转
import { useAuthStore } from '../stores/auth'; // 假设你的 auth store 在这个路径

const authStore = useAuthStore();
const router = useRouter(); // 获取 router 实例

// 表单数据
const username = ref('');
const password = ref('');

// 客户端校验错误信息 (本地管理)
const clientErrorMessage = ref('');

// 处理登录提交
const handleLogin = async () => {
  // 清除之前的客户端错误提示
  clientErrorMessage.value = '';
  // 同时清除 store 中可能存在的旧的登录错误 (如果用户再次尝试)
  if (authStore.loginStatus.error) {
      authStore.loginStatus.error = null;
  }

  // 客户端简单校验
  if (!username.value.trim() || !password.value.trim()) {
    clientErrorMessage.value = '用户名和密码都不能为空。';
    return;
  }

  // 调用 authStore 中的 login action
  // login action 内部会设置 isLoading, error, 并在成功后跳转
  const success = await authStore.login({
    username: username.value,
    password: password.value
  });

  if (success) {
    // 登录成功，跳转逻辑已在 authStore.login action 中处理 (检查 redirect query)
    console.log('LoginPage: 登录成功，跳转由 authStore 处理。');
  } else {
    // 登录失败，错误信息应该由 authStore.loginStatus.error 提供
    // 模板中会直接显示 authStore.loginStatus.error
    console.log('LoginPage: 登录失败，错误信息:', authStore.loginStatus.error);
    // 如果后端没有返回具体的错误信息，或者你想给一个通用提示
    // 错误信息由模板直接显示 authStore.loginStatus.error
  }
};
</script>

<template>
  <div class="login-page-container">
    <div class="login-form">
      <h2>系统登录</h2>
      <form @submit.prevent="handleLogin" novalidate>
        <div class="form-group">
          <label for="username">用户名 <span class="required">*</span></label>
          <input
            type="text"
            id="username"
            v-model.trim="username"
            placeholder="请输入用户名"
            required
            aria-describedby="username-error client-error-message server-error-message"
            :class="{'is-invalid': clientErrorMessage || (authStore.loginStatus.error && authStore.loginStatus.error.includes('用户名'))}"
          />
           <div v-if="clientErrorMessage && clientErrorMessage.includes('用户名')" class="invalid-feedback">{{ clientErrorMessage }}</div>
           <div v-else-if="authStore.loginStatus.error && authStore.loginStatus.error.includes('用户名')" class="invalid-feedback">{{ authStore.loginStatus.error }}</div>
        </div>
        <div class="form-group">
          <label for="password">密码 <span class="required">*</span></label>
          <input
            type="password"
            id="password"
            v-model.trim="password"
            placeholder="请输入密码"
            required
            aria-describedby="password-error client-error-message server-error-message"
             :class="{'is-invalid': clientErrorMessage || (authStore.loginStatus.error && authStore.loginStatus.error.includes('密码'))}"
          />
           <div v-if="clientErrorMessage && clientErrorMessage.includes('密码')" class="invalid-feedback">{{ clientErrorMessage }}</div>
           <div v-else-if="authStore.loginStatus.error && authStore.loginStatus.error.includes('密码')" class="invalid-feedback">{{ authStore.loginStatus.error }}</div>
        </div>

        <!-- 显示通用客户端校验错误 -->
        <div v-if="clientErrorMessage && !clientErrorMessage.includes('用户名') && !clientErrorMessage.includes('密码')" class="error-message client-error" id="client-error-message" role="alert">
          {{ clientErrorMessage }}
        </div>

        <!-- 显示来自 Store (后端或网络) 的通用错误信息 -->
        <div v-if="authStore.loginStatus.error && !authStore.loginStatus.error.includes('用户名') && !authStore.loginStatus.error.includes('密码')"
             class="error-message server-error" id="server-error-message" role="alert">
          {{ authStore.loginStatus.error }}
        </div>


        <button type="submit" :disabled="authStore.loginStatus.isLoading" class="login-button">
          <span v-if="authStore.loginStatus.isLoading" class="spinner" aria-hidden="true"></span>
          <span v-if="authStore.loginStatus.isLoading">登录中...</span>
          <span v-else>登 录</span>
        </button>
      </form>
      <!-- “还没有账户”链接：未注释，直接显示 -->
      <div class="links">
        <p>还没有账户? <router-link to="/register">立即注册</router-link></p>
      </div>
    </div>
  </div>
</template>

<style scoped>
.login-page-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  min-height: calc(100vh - 60px);
  padding: 20px;
  background-color: #f0f2f5;
}

.login-form {
  background: #ffffff;
  padding: 2.5rem 3rem;
  border-radius: 10px;
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
  width: 100%;
  max-width: 420px;
  border-top: 5px solid #007bff;
}

.login-form h2 {
  text-align: center;
  margin-bottom: 2rem;
  color: #343a40;
  font-size: 1.8rem;
  font-weight: 600;
}

.form-group {
  margin-bottom: 1.5rem;
}

.form-group label {
  display: block;
  margin-bottom: 0.6rem;
  font-weight: 500;
  color: #495057;
}

.form-group input {
  width: 100%;
  padding: 0.85rem 1rem;
  border: 1px solid #ced4da;
  border-radius: 5px;
  font-size: 1rem;
  color: #495057;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}

.form-group input:focus {
  border-color: #80bdff;
  outline: 0;
  box-shadow: 0 0 0 0.25rem rgba(0, 123, 255, 0.25);
}

.form-group .is-invalid {
    border-color: #dc3545;
}


.invalid-feedback {
   display: block;
   width: 100%;
   margin-top: 0.25rem;
   font-size: 0.875em;
   color: #dc3545;
}

 .required {
  color: #dc3545;
  margin-left: 4px;
 }

.login-button {
  width: 100%;
  padding: 0.85rem;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  font-size: 1.1rem;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.2s ease-in-out, transform 0.1s ease;
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
}

.login-button:hover:not(:disabled) {
  background-color: #0056b3;
  transform: translateY(-1px);
}

.login-button:active:not(:disabled) {
  transform: translateY(0px);
}

.login-button:disabled {
  background-color: #6c757d;
  cursor: not-allowed;
}

.error-message {
  color: #721c24;
  background-color: #f8d7da;
  border: 1px solid #f5c6cb;
  padding: 0.85rem 1rem;
  border-radius: 5px;
  margin-bottom: 1.5rem;
  text-align: left;
  font-size: 0.9rem;
}

.links {
  margin-top: 1.5rem;
  text-align: center;
  font-size: 0.9rem;
}

.links p {
  margin-bottom: 0.5rem;
}

.links a {
  color: #007bff;
  text-decoration: none;
}

.links a:hover {
  text-decoration: underline;
}

.spinner {
  display: inline-block;
  width: 1.2em;
  height: 1.2em;
  margin-right: 0.7em;
  border: 3px solid rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  border-top-color: #fff;
  animation: spin 0.8s linear infinite;
  vertical-align: middle;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
</style>