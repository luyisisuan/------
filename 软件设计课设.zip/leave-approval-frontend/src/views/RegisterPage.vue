<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
// 导入 auth store，假设路径正确
import { useAuthStore } from '../stores/auth';

const router = useRouter();
// 获取 auth store 实例
const authStore = useAuthStore();

// 表单数据，使用 ref 创建响应式引用
const username = ref('');
const email = ref('');
const password = ref('');
const fullName = ref('');
const confirmPassword = ref(''); // 确认密码字段

// 客户端校验错误信息，本地管理
const clientErrors = ref({});

/**
 * 处理用户注册表单提交
 */
const handleRegister = async () => {
  // 1. 客户端校验前，清空之前的错误提示和状态
  clientErrors.value = {};
  // 清除 Store 中的注册错误状态和成功状态，用户再次尝试注册时需要重置
  authStore.registrationStatus.error = null;
  authStore.registrationStatus.isSuccess = false;

  // 执行客户端表单字段校验
  if (!username.value.trim()) clientErrors.value.username = '用户名不能为空。';
  if (!email.value.trim()) clientErrors.value.email = '邮箱不能为空。';
  // 简单的邮箱格式校验
  else if (!/\S+@\S+\.\S+/.test(email.value.trim())) clientErrors.value.email = '请输入有效的邮箱格式。';
  if (!password.value.trim()) clientErrors.value.password = '密码不能为空。';
  // 密码长度校验，需要与后端校验规则一致或更严格
  else if (password.value.trim().length < 6) clientErrors.value.password = '密码至少需要6个字符。';
  if (!fullName.value.trim()) clientErrors.value.fullName = '姓名不能为空。';
  // 确认密码校验
  if (password.value !== confirmPassword.value) clientErrors.value.confirmPassword = '两次输入的密码不一致。';


  // 如果存在任何客户端校验错误，则停止提交
  if (Object.keys(clientErrors.value).length > 0) {
    console.log('RegisterPage: 客户端校验失败，停止提交。');
    return;
  }

  console.log('RegisterPage: 客户端校验通过，尝试调用注册 action。');

  // 2. 构建发送到后端的请求数据
  const requestData = {
    username: username.value.trim(),
    email: email.value.trim(),
    password: password.value.trim(),
    fullName: fullName.value.trim(),
    // 后端默认分配角色，这里不需要传递 roles
  };

  // 3. 调用 authStore 中的注册 action 发起注册流程
  // authStore.register 会管理 isLoading, error, isSuccess 状态
  const success = await authStore.register(requestData);

  if (success) {
      // 注册 action 调用成功，意味着 API 请求成功且后端返回了 2xx 状态码
      console.log('RegisterPage: 注册 action 调用成功，后端返回成功响应。');
      // 注册成功状态已由 store 设置，模板会响应并显示成功消息
      // 可以选择在注册成功后清空表单字段，方便再次注册
      // resetFormFields(); // 只清空字段，保留成功提示
  } else {
      // 注册 action 调用失败，意味着 API 请求失败（非 2xx 状态码或网络错误）
      console.log('RegisterPage: 注册 action 调用失败，请检查 authStore.registrationStatus.error 获取详细信息。');
      // 错误信息已由 store 设置，模板会响应并显示错误消息
  }
};

/**
 * 清空所有表单字段和客户端错误提示
 */
const resetFormFields = () => {
  username.value = '';
  email.value = '';
  password.value = '';
  fullName.value = '';
  confirmPassword.value = '';
  clientErrors.value = {};
};

/**
 * 重置整个表单状态，包括字段、客户端错误和 Store 中的注册状态
 * 通常在注册成功后点击“注册新账户”按钮时调用
 */
const resetForm = () => {
    resetFormFields(); // 清空字段和客户端错误
    // 清空 store 中的注册状态，隐藏成功/失败提示
    authStore.registrationStatus.error = null;
    authStore.registrationStatus.isSuccess = false;
    console.log('RegisterPage: 表单状态已重置。');
};

// 如果需要，可以在组件挂载时做一些初始化操作
// onMounted(() => {
//   // 例如，确保 authStore 已经从本地存储加载了状态 (虽然通常在 main.js 或 App.vue 中处理更好)
//   // authStore.initialize();
// });

</script>

<template>
  <div class="register-page-container">
    <div class="register-form">
      <h2>用户注册</h2>
      <!-- 使用 @submit.prevent 阻止表单默认提交行为，改由 Vue 方法处理 -->
      <form @submit.prevent="handleRegister" novalidate>

        <!-- 用户名输入组 -->
        <div class="form-group">
          <label for="register-username">用户名 <span class="required">*</span></label>
          <input
            type="text"
            id="register-username"
            v-model.trim="username"
            placeholder="请输入用户名"
            required
            :class="{'is-invalid': clientErrors.username || (authStore.registrationStatus.error && typeof authStore.registrationStatus.error === 'string' && authStore.registrationStatus.error.includes('Username'))}"
          />
           <!-- 显示客户端校验错误 -->
           <div v-if="clientErrors.username" class="invalid-feedback">{{ clientErrors.username }}</div>
           <!-- 如果服务端错误包含“Username”相关的提示，在这里显示 -->
           <!-- 添加对 authStore.registrationStatus 的存在检查 -->
           <div v-else-if="authStore.registrationStatus && authStore.registrationStatus.error && typeof authStore.registrationStatus.error === 'string' && authStore.registrationStatus.error.includes('Username')" class="invalid-feedback">{{ authStore.registrationStatus.error }}</div>
        </div>

        <!-- 邮箱输入组 -->
         <div class="form-group">
          <label for="register-email">邮箱 <span class="required">*</span></label>
          <input
            type="email"
            id="register-email"
            v-model.trim="email"
            placeholder="请输入邮箱"
            required
            :class="{'is-invalid': clientErrors.email || (authStore.registrationStatus.error && typeof authStore.registrationStatus.error === 'string' && authStore.registrationStatus.error.includes('Email'))}"
          />
          <div v-if="clientErrors.email" class="invalid-feedback">{{ clientErrors.email }}</div>
           <!-- 如果服务端错误包含“Email”相关的提示，在这里显示 -->
           <!-- 添加对 authStore.registrationStatus 的存在检查 -->
           <div v-else-if="authStore.registrationStatus && authStore.registrationStatus.error && typeof authStore.registrationStatus.error === 'string' && authStore.registrationStatus.error.includes('Email')" class="invalid-feedback">{{ authStore.registrationStatus.error }}</div>
        </div>

        <!-- 密码输入组 -->
        <div class="form-group">
          <label for="register-password">密码 <span class="required">*</span></label>
          <input
            type="password"
            id="register-password"
            v-model.trim="password"
            placeholder="请输入密码"
            required
            :class="{'is-invalid': clientErrors.password || (authStore.registrationStatus.error && typeof authStore.registrationStatus.error === 'string' && authStore.registrationStatus.error.includes('密码'))}"
          />
           <div v-if="clientErrors.password" class="invalid-feedback">{{ clientErrors.password }}</div>
           <!-- 如果服务端错误包含“密码”相关的提示，在这里显示 -->
           <!-- 添加对 authStore.registrationStatus 的存在检查 -->
            <div v-else-if="authStore.registrationStatus && authStore.registrationStatus.error && typeof authStore.registrationStatus.error === 'string' && authStore.registrationStatus.error.includes('密码')" class="invalid-feedback">{{ authStore.registrationStatus.error }}</div>
        </div>

        <!-- 确认密码输入组 -->
         <div class="form-group">
          <label for="register-confirm-password">确认密码 <span class="required">*</span></label>
          <input
            type="password"
            id="register-confirm-password"
            v-model.trim="confirmPassword"
            placeholder="请再次输入密码"
            required
             :class="{'is-invalid': clientErrors.confirmPassword}"
          />
           <div v-if="clientErrors.confirmPassword" class="invalid-feedback">{{ clientErrors.confirmPassword }}</div>
        </div>

        <!-- 姓名输入组 -->
         <div class="form-group">
          <label for="register-fullName">姓名 <span class="required">*</span></label>
          <input
            type="text"
            id="register-fullName"
            v-model.trim="fullName"
            placeholder="请输入您的真实姓名"
            required
             :class="{'is-invalid': clientErrors.fullName}"
          />
           <div v-if="clientErrors.fullName" class="invalid-feedback">{{ clientErrors.fullName }}</div>
        </div>


        <!-- 显示服务端通用错误信息 (不包含特定字段关键词的错误) -->
        <!-- 添加对 authStore.registrationStatus 的存在检查 -->
        <div v-if="authStore.registrationStatus && authStore.registrationStatus.error && typeof authStore.registrationStatus.error === 'string' && !authStore.registrationStatus.error.includes('Username') && !authStore.registrationStatus.error.includes('Email') && !authStore.registrationStatus.error.includes('密码')"
             class="alert alert-danger" role="alert">
          {{ authStore.registrationStatus.error }}
        </div>


         <!-- 显示注册成功信息 -->
         <!-- 添加对 authStore.registrationStatus 的存在检查 -->
         <div v-if="authStore.registrationStatus && authStore.registrationStatus.isSuccess" class="alert alert-success" role="alert">
           恭喜您，注册成功！请 <router-link to="/login">前往登录页面</router-link> 进行登录。
         </div>


        <!-- 提交按钮 -->
        <!-- 禁用条件绑定到 store 的 loading 状态和成功状态 -->
        <button type="submit" :disabled="authStore.registrationStatus.isLoading || authStore.registrationStatus.isSuccess" class="register-button">
          <!-- 加载中图标和文字 -->
          <span v-if="authStore.registrationStatus.isLoading" class="spinner"></span>
          <span v-if="authStore.registrationStatus.isLoading">注册中...</span>
          <!-- 正常文字 -->
          <span v-else>注册</span>
        </button>

         <!-- 注册成功后显示“注册新账户”按钮 -->
         <button v-if="authStore.registrationStatus && authStore.registrationStatus.isSuccess" type="button" @click="resetForm" class="btn btn-secondary mt-3">
           注册新账户
         </button>

      </form>
       <!-- “已有账户”链接 -->
       <div class="links">
          <p>已有账户? <router-link to="/login">立即登录</router-link></p>
        </div>
    </div>
  </div>
</template>

<style scoped>
/* 复用或修改 login page 的样式 */
/* 页面容器样式 */
.register-page-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  /* 确保内容区域最小高度覆盖视口，减去导航栏高度 */
  min-height: calc(100vh - 60px);
  padding: 20px;
  background-color: #f0f2f5; /* 页面背景色 */
}

/* 注册表单卡片样式 */
.register-form {
  background: #ffffff; /* 背景白色 */
  padding: 2.5rem 3rem; /* 内边距 */
  border-radius: 10px; /* 圆角 */
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1); /* 阴影 */
  width: 100%; /* 宽度 */
  max-width: 450px; /* 最大宽度，控制表单大小 */
  border-top: 5px solid #17a2b8; /* 顶部装饰线，注册表单使用不同颜色 */
}

/* 表单标题样式 */
.register-form h2 {
  text-align: center; /* 居中 */
  margin-bottom: 2rem; /* 底部外边距 */
  color: #343a40; /* 标题颜色 */
  font-size: 1.8rem; /* 字体大小 */
  font-weight: 600; /* 字体粗细 */
}

/* 表单组容器样式 */
.form-group {
  margin-bottom: 1.5rem; /* 底部外边距 */
}

/* Label 样式 */
.form-group label {
  display: block; /* 独占一行 */
  margin-bottom: 0.6rem; /* 底部外边距 */
  font-weight: 500; /* 字体粗细 */
  color: #495057; /* 文字颜色 */
}

/* 输入框样式 */
.form-group input,
.form-group select, /* 如果有 select 元素 */
.form-group textarea /* 如果有 textarea 元素 */ {
  width: 100%; /* 宽度100% */
  padding: 0.85rem 1rem; /* 内边距 */
  border: 1px solid #ced4da; /* 边框 */
  border-radius: 5px; /* 圆角 */
  font-size: 1rem; /* 字体大小 */
  color: #495057; /* 文字颜色 */
  /* 过渡效果 */
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}

/* 输入框获取焦点时的样式 */
.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
  border-color: #80bdff; /* 边框颜色变化 */
  outline: 0; /* 移除默认轮廓 */
  box-shadow: 0 0 0 0.25rem rgba(0, 123, 255, 0.25); /* 阴影效果 */
}

/* 校验失败时输入框的边框样式 */
.form-group .is-invalid {
    border-color: #dc3545; /* 边框变红色 */
}

/* 校验失败时的提示文字样式 */
.invalid-feedback {
   display: block; /* 独占一行 */
   width: 100%;
   margin-top: 0.25rem; /* 顶部外边距 */
   font-size: 0.875em; /* 字体大小 */
   color: #dc3545; /* 文字颜色红色 */
}

/* 必填项标记 (*) 的样式 */
.required {
 color: #dc3545; /* 红色 */
 margin-left: 4px; /* 左侧外边距 */
}


/* 注册按钮样式 */
.register-button {
  width: 100%; /* 宽度100% */
  padding: 0.85rem; /* 内边距 */
  background-color: #17a2b8; /* 背景颜色，注册按钮使用蓝色系 */
  color: white; /* 文字颜色白色 */
  border: none; /* 无边框 */
  border-radius: 5px; /* 圆角 */
  font-size: 1.1rem; /* 字体大小 */
  font-weight: 500; /* 字体粗细 */
  cursor: pointer; /* 鼠标样式为手型 */
  /* 过渡和动画 */
  transition: background-color 0.2s ease-in-out, transform 0.1s ease;
  display: flex; /* flex布局 */
  justify-content: center; /* 内容水平居中 */
  align-items: center; /* 内容垂直居中 */
  position: relative; /* 用于内部 spinner 的定位 */
}

/* 注册按钮 Hover 时的样式 */
.register-button:hover:not(:disabled) {
  background-color: #138496; /* 背景颜色变深 */
  transform: translateY(-1px); /* 向上轻微移动 */
}

/* 注册按钮 Active (按下) 时的样式 */
.register-button:active:not(:disabled) {
  transform: translateY(0px); /* 恢复位置 */
}

/* 注册按钮禁用时的样式 */
.register-button:disabled {
  background-color: #6c757d; /* 灰色背景 */
  cursor: not-allowed; /* 鼠标样式为禁用 */
}

/* 加载中的 spinner 样式 */
.spinner {
  display: inline-block; /* 行内块元素 */
  width: 1.2em; /* 宽度 */
  height: 1.2em; /* 高度 */
  margin-right: 0.7em; /* 右侧外边距 */
  border: 3px solid rgba(255, 255, 255, 0.3); /* 边框透明度 */
  border-radius: 50%; /* 圆形 */
  border-top-color: #fff; /* 顶部边框颜色，用于动画 */
  animation: spin 0.8s linear infinite; /* 应用动画 */
  vertical-align: middle; /* 垂直对齐 */
}

/* spinner 旋转动画 */
@keyframes spin {
  to {
    transform: rotate(360deg); /* 旋转一周 */
  }
}

/* 通用 Alert 样式 */
.alert {
    padding: 1rem 1.25rem; /* 内边距 */
    margin-bottom: 1.5rem; /* 底部外边距 */
    border: 1px solid transparent; /* 边框 */
    border-radius: 0.25rem; /* 圆角 */
 }

/* 警告 Alert (错误) 样式 */
 .alert-danger {
    color: #721c24; /* 文字颜色 */
    background-color: #f8d7da; /* 背景颜色 */
    border-color: #f5c6cb; /* 边框颜色 */
 }

/* 成功 Alert 样式 */
  .alert-success {
     color: #155724;
     background-color: #d4edda;
     border-color: #c3e6cb;
  }

/* 次级按钮样式 (用于“注册新账户”等) */
  .btn-secondary {
      background-color: #6c757d;
      color: white;
      border: none;
      border-radius: 5px;
      padding: 0.85rem;
      font-size: 1.1rem;
      font-weight: 500;
      cursor: pointer;
      transition: background-color 0.2s;
      width: 100%;
  }

  .btn-secondary:hover {
      background-color: #5a6268;
  }

/* 顶部外边距工具类 */
  .mt-3 {
      margin-top: 1rem;
  }

/* 已有账户/立即登录链接容器样式 */
.links {
  margin-top: 1.5rem;
  text-align: center;
  font-size: 0.9rem;
}

.links p {
  margin-bottom: 0.5rem;
}

.links a {
  color: #007bff;
  text-decoration: none;
}

.links a:hover {
  text-decoration: underline;
}
</style>