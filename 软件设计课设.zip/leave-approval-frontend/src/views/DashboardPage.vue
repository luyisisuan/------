<script setup>
import { computed, onMounted } from 'vue';
import { useAuthStore } from '../stores/auth';

const authStore = useAuthStore();

const welcomeMessage = computed(() => {
  if (authStore.currentUser && (authStore.currentUser.fullName || authStore.currentUser.username)) {
    return `欢迎回来, ${authStore.currentUser.fullName || authStore.currentUser.username}!`;
  }
  return '欢迎访问请假审批系统!';
});

const userRoleDisplay = computed(() => {
  if (authStore.userRoles && authStore.userRoles.length > 0) {
    return authStore.userRoles
      .map(role => {
        const cleanedRole = role.replace('ROLE_', '');
        return cleanedRole.charAt(0).toUpperCase() + cleanedRole.slice(1).toLowerCase();
      })
      .join(', ');
  }
  return '访客';
});

const canApprove = computed(() => {
  if (!authStore.isAuthenticated || !authStore.userRoles) {
    return false;
  }
  const approverRoles = ['ROLE_TEAM_LEAD', 'ROLE_DEPT_MANAGER', 'ROLE_HR', 'ROLE_ADMIN'];
  return authStore.userRoles.some(role => approverRoles.includes(role));
});

const isAdmin = computed(() => {
  if (!authStore.isAuthenticated || !authStore.userRoles) {
    return false;
  }
  return authStore.userRoles.includes('ROLE_ADMIN');
});

onMounted(() => {
  // if (authStore.isAuthenticated && !authStore.currentUser) {
  //   authStore.fetchCurrentUser().catch(error => {
  //     console.error("获取用户信息失败:", error);
  //   });
  // }
});

const quickActions = computed(() => [
  {
    to: '/submit-leave',
    icon: '📄',
    title: '提交请假',
    description: '填写并提交新的请假申请。',
    show: authStore.isAuthenticated,
  },
  {
    to: '/my-requests',
    icon: '📂',
    title: '我的申请',
    description: '查看您提交的请假记录和状态。',
    show: authStore.isAuthenticated,
  },
  {
    to: '/pending-approvals',
    icon: '✔️',
    title: '待我审批',
    description: '处理等待您审批的请假申请。',
    show: canApprove.value,
  },
  {
    to: '/admin/users',
    icon: '👥',
    title: '用户管理',
    description: '管理系统用户账户和角色。',
    show: isAdmin.value,
  },
]);
</script>

<template>
  <div class="dashboard-container">
    <header class="dashboard-header">
      <h1>{{ welcomeMessage }}</h1>
      <p v-if="authStore.isAuthenticated" class="role-info">您的当前角色: {{ userRoleDisplay }}</p>
    </header>

    <section v-if="authStore.isAuthenticated" class="quick-actions">
      <h2>快速操作</h2>
      <div class="actions-grid">
        <router-link
          v-for="action in quickActions.filter(a => a.show)"
          :key="action.to"
          :to="action.to"
          class="action-card"
        >
          <div class="action-icon">{{ action.icon }}</div>
          <h3>{{ action.title }}</h3>
          <p>{{ action.description }}</p>
        </router-link>
      </div>
    </section>
    <section v-else class="guest-info">
      <p>请 <router-link to="/login">登录</router-link> 以使用系统功能。</p>
    </section>
  </div>
</template>

<style scoped>
.dashboard-container {
  max-width: 1000px;
  margin: 2rem auto;
  padding: 2rem 1.5rem;
  background-color: #f9f9f9;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
}

.dashboard-header {
  text-align: center;
  margin-bottom: 3rem;
  padding-bottom: 1.5rem;
  border-bottom: 2px solid #e9ecef;
}

.dashboard-header h1 {
  font-size: 2.5rem;
  color: #343a40;
  margin-bottom: 0.75rem;
  font-weight: 600;
}

.role-info {
  font-size: 1.1rem;
  color: #6c757d;
}

.quick-actions h2 {
  font-size: 2rem;
  color: #343a40;
  margin-bottom: 2rem;
  text-align: center;
  font-weight: 500;
}

.actions-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 2rem;
}

.action-card {
  background-color: #ffffff;
  padding: 2rem 1.5rem;
  border-radius: 12px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.06);
  text-decoration: none;
  color: inherit;
  transition: transform 0.25s ease-in-out, box-shadow 0.25s ease-in-out;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  border: 1px solid #e9ecef;
}

.action-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
}

.action-icon {
  font-size: 3rem;
  margin-bottom: 1.25rem;
  line-height: 1;
  color: #007bff;
}

.action-card h3 {
  font-size: 1.3rem;
  margin-bottom: 0.75rem;
  color: #212529;
  font-weight: 500;
}

.action-card p {
  font-size: 0.95rem;
  color: #495057;
  line-height: 1.5;
}

.guest-info {
  text-align: center;
  padding: 2rem;
  font-size: 1.2rem;
  color: #6c757d;
}
.guest-info a {
  color: #007bff;
  text-decoration: none;
  font-weight: bold;
}
.guest-info a:hover {
  text-decoration: underline;
}
</style>