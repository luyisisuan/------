// src/main.js
import { createApp } from 'vue';
import { createPinia } from 'pinia';
import App from './App.vue';
import router from './router';
import './assets/main.css'; // 全局样式

// 创建 Vue 应用
const app = createApp(App);

// 安装 Pinia
const pinia = createPinia();
app.use(pinia);

// 安装路由
app.use(router);

// （可选）应用启动时检查 Token 有效性
// import { useAuthStore } from './stores/auth';
// const authStore = useAuthStore();
// authStore.checkAuthStatus?.(); // 如果你实现了该方法

// 挂载应用
app.mount('#app');
