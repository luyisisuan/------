package com.example.leaveapproval.service.leave.impl;

import com.example.leaveapproval.dto.ApprovalActionDto;
import com.example.leaveapproval.dto.ApprovalHistoryViewDto;
import com.example.leaveapproval.dto.LeaveRequestCreateDto;
import com.example.leaveapproval.dto.LeaveRequestViewDto;
import com.example.leaveapproval.exception.ResourceNotFoundException;
import com.example.leaveapproval.model.*; // User, LeaveRequest, ApprovalHistory, Role, LeaveStatus, LeaveType
import com.example.leaveapproval.repository.ApprovalHistoryRepository;
import com.example.leaveapproval.repository.LeaveRequestRepository;
import com.example.leaveapproval.repository.UserRepository;
import com.example.leaveapproval.service.approval.chain.Approver;
import com.example.leaveapproval.service.leave.LeaveRequestManagementService;
import com.example.leaveapproval.service.leave.LeaveRequestProcessService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class LeaveRequestManagementServiceImpl implements LeaveRequestManagementService {

    private static final Logger logger = LoggerFactory.getLogger(LeaveRequestManagementServiceImpl.class);

    private final LeaveRequestRepository leaveRequestRepository;
    private final UserRepository userRepository;
    private final ApprovalHistoryRepository approvalHistoryRepository;
    private final LeaveRequestProcessService leaveRequestProcessService;
    private final ApplicationContext applicationContext;

    @Autowired
    public LeaveRequestManagementServiceImpl(
            LeaveRequestRepository leaveRequestRepository,
            UserRepository userRepository,
            ApprovalHistoryRepository approvalHistoryRepository,
            @Qualifier("genericLeaveProcessService") LeaveRequestProcessService leaveRequestProcessService,
            ApplicationContext applicationContext) {
        this.leaveRequestRepository = leaveRequestRepository;
        this.userRepository = userRepository;
        this.approvalHistoryRepository = approvalHistoryRepository;
        this.leaveRequestProcessService = leaveRequestProcessService;
        this.applicationContext = applicationContext;
    }

    private User getCurrentAuthenticatedUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated() || !(authentication.getPrincipal() instanceof User)) {
            String principalName = authentication != null ? authentication.getPrincipal().toString() : "null";
            logger.warn("无法获取当前认证用户，认证信息主体为: {}", principalName);
            throw new IllegalStateException("用户未登录或认证信息无效。请重新登录。");
        }
        return (User) authentication.getPrincipal();
    }

    @Override
    public LeaveRequestViewDto submitLeaveRequest(LeaveRequestCreateDto createDto) {
        logger.info("接收到新的请假申请提交请求。");
        LeaveRequestViewDto createdLeaveRequest = leaveRequestProcessService.submitLeaveRequest(createDto);
        logger.info("请假申请 (ID: {}) 已成功提交并启动审批流程，当前状态: {}",
                createdLeaveRequest.getId(), createdLeaveRequest.getStatus());
        return createdLeaveRequest;
    }

    @Override
    public LeaveRequestViewDto processApprovalAction(Long leaveRequestId, ApprovalActionDto actionDto, Long approverUserId) {
        logger.info("用户ID {} 尝试处理请假申请ID {}，决定：{}，意见：'{}'",
                approverUserId, leaveRequestId, actionDto.getDecision(), actionDto.getComments());

        LeaveRequest leaveRequest = leaveRequestRepository.findById(leaveRequestId)
                .orElseThrow(() -> {
                    logger.warn("处理审批操作失败：未找到请假申请ID {}", leaveRequestId);
                    return new ResourceNotFoundException("LeaveRequest", "id", leaveRequestId);
                });

        User actionTakingApprover = userRepository.findById(approverUserId)
                .orElseThrow(() -> {
                    logger.warn("处理审批操作失败：未找到执行操作的用户ID {}", approverUserId);
                    return new ResourceNotFoundException("User (Approver)", "id", approverUserId);
                });

        if (leaveRequest.getStatusEnum() != LeaveStatus.PENDING_APPROVAL) {
            String errorMsg = String.format("请假申请 %d 当前状态为 %s，不允许执行审批操作。",
                    leaveRequestId, leaveRequest.getStatusEnum());
            logger.warn(errorMsg + " 操作用户: {}", actionTakingApprover.getUsername());
            throw new IllegalStateException(errorMsg);
        }

        // 权限校验：Admin 可以操作任何 PENDING_APPROVAL 的单据，其他人必须是当前指定审批人
        boolean isAdminAction = actionTakingApprover.getRoles().contains(Role.ROLE_ADMIN);
        boolean isCurrentUserAssignedApprover = (leaveRequest.getCurrentApprover() != null &&
                leaveRequest.getCurrentApprover().getId().equals(actionTakingApprover.getId()));

        if (!isAdminAction && !isCurrentUserAssignedApprover) {
            String currentApproverUsername = leaveRequest.getCurrentApprover() != null ? leaveRequest.getCurrentApprover().getUsername() : "未指定";
            String errorMsg = String.format("权限不足：用户 %s 不是请假申请 %d 的当前指定审批人 (%s) 且不具备越级审批权限。",
                    actionTakingApprover.getUsername(), leaveRequestId, currentApproverUsername);
            logger.warn(errorMsg);
            throw new IllegalStateException(errorMsg);
        }

        // 确定使用哪个 Approver 节点进行处理
        // 如果是 Admin 且不是当前指定审批人（即越级审批），Admin 通常会使用自己的权限直接处理，
        // 或者我们仍然让流程通过当前指定的审批人对应的节点（例如 TeamLeadApprover），
        // 但在 Approver 节点内部可以根据 actionTakingApprover 是否是 Admin 来调整行为（例如 Admin 批准后直接最终批准）。
        // 为了简化，我们先假设：如果 Admin 操作，并且他是当前审批人，则按正常流程；
        // 如果 Admin 操作，但他不是当前审批人，则可能需要一个特殊的 Admin 处理逻辑或直接更新状态。
        // 目前的 getApproverNodeForUser 是根据单据的 currentApprover 角色来的。
        // 如果 Admin 要越级，他实际上是代替了 currentApprover 的角色行为，但以 Admin 身份记录。

        User designatedApproverForNode = leaveRequest.getCurrentApprover();
        if (designatedApproverForNode == null) {
            // 这种情况理论上不应发生，因为 PENDING_APPROVAL 状态应该有 currentApprover
            // 但如果发生了，并且是 Admin 在操作，可以考虑让 Admin 成为一个默认的审批节点
            if (isAdminAction) {
                designatedApproverForNode = actionTakingApprover; // 让 Admin 匹配他自己的审批节点
                logger.warn("请假申请 {} 无当前审批人，Admin {} 尝试处理。", leaveRequestId, actionTakingApprover.getUsername());
            } else {
                throw new IllegalStateException("请假申请 " + leaveRequestId + " 没有指定的当前审批人，无法处理。");
            }
        }

        Approver approverNode = getApproverNodeForUser(designatedApproverForNode);
        if (approverNode == null) {
            String errorMsg = String.format(
                    "系统错误：无法为当前应审批用户 %s (ID: %d, 角色: %s) 找到对应的审批处理者配置。",
                    designatedApproverForNode.getUsername(),
                    designatedApproverForNode.getId(),
                    designatedApproverForNode.getRoles()
            );
            logger.error(errorMsg);
            throw new IllegalStateException(errorMsg);
        }

        try {
            // 将实际操作者 (actionTakingApprover) 传递给职责链
            approverNode.handleApprovalAction(leaveRequest, actionTakingApprover, actionDto.getDecision(), actionDto.getComments());
            logger.info("请假申请 ID: {} 的审批操作已由 {} (ID: {}) 代表节点 {} 处理完成。",
                    leaveRequestId, actionTakingApprover.getUsername(), actionTakingApprover.getId(), designatedApproverForNode.getUsername());
        } catch (IllegalStateException e) {
            logger.warn("请假申请 ID: {} 的审批操作失败：{}", leaveRequestId, e.getMessage());
            throw e;
        }

        LeaveRequest updatedRequest = leaveRequestRepository.findById(leaveRequestId)
                .orElseThrow(() -> new InternalError("严重错误：处理审批后无法重新获取请假申请 " + leaveRequestId + "。"));

        return populateLeaveRequestViewDto(updatedRequest);
    }

    private Approver getApproverNodeForUser(User user) {
        if (user == null || user.getRoles() == null || user.getRoles().isEmpty()) {
            logger.warn("尝试为没有角色或为null的用户获取Approver节点：{}", user != null ? user.getUsername() : "null用户");
            return null;
        }
        // 优先级：HR > DeptManager > TeamLead
        if (user.getRoles().contains(Role.ROLE_HR)) {
            return applicationContext.getBean("hrApprover", Approver.class);
        } else if (user.getRoles().contains(Role.ROLE_DEPT_MANAGER)) {
            return applicationContext.getBean("deptManagerApprover", Approver.class);
        } else if (user.getRoles().contains(Role.ROLE_TEAM_LEAD)) {
            return applicationContext.getBean("teamLeadApprover", Approver.class);
        }
        // 如果是 Admin 但没有其他审批角色，Admin 的审批可能需要特殊处理或专用 Approver 节点
        // 或者 Admin 总是通过其拥有的其他审批角色（如HR）来执行操作
        if (user.getRoles().contains(Role.ROLE_ADMIN)) {
            logger.info("Admin用户 {} 正在审批，尝试匹配其最高审批角色对应的节点（或默认HR）。", user.getUsername());
            // 可以根据业务规则为 Admin 指定一个默认的审批节点，例如 HR
            // 如果 Admin 也有 ROLE_HR，上面的逻辑已经覆盖
            // 如果 Admin 只有 ROLE_ADMIN，你可能需要一个 AdminApprover 或让其行为像最高级审批者
            // 为简单起见，如果 Admin 没有明确的审批角色，且流程到了他这里，可能表示流程配置问题或 Admin 需要直接干预
            // 暂时不为纯 ADMIN 角色返回特定审批节点，依赖于他是否兼任其他审批角色
        }
        logger.warn("用户 {} (ID: {}) 具有角色 {}，但没有匹配的特定审批处理者节点配置。",
                user.getUsername(), user.getId(), user.getRoles());
        return null; // 或者抛出配置异常
    }

    @Override
    public LeaveRequestViewDto cancelLeaveRequest(Long leaveRequestId, Long applicantId) {
        logger.info("用户ID {} 尝试取消请假申请ID {}", applicantId, leaveRequestId);
        LeaveRequest leaveRequest = leaveRequestRepository.findById(leaveRequestId)
                .orElseThrow(() -> new ResourceNotFoundException("LeaveRequest", "id", leaveRequestId));
        User actionTaker = userRepository.findById(applicantId)
                .orElseThrow(() -> new ResourceNotFoundException("User (Action Taker)", "id", applicantId));

        if (!leaveRequest.getApplicant().getId().equals(actionTaker.getId())) {
            String errorMsg = String.format("权限不足：用户 %s 不是请假申请 %d 的申请人。",
                    actionTaker.getUsername(), leaveRequestId);
            logger.warn(errorMsg);
            throw new IllegalStateException(errorMsg);
        }

        try {
            leaveRequest.cancel(actionTaker); // 假设实体方法更新内存状态
            LeaveRequest cancelledRequest = leaveRequestRepository.save(leaveRequest); // Service层负责保存
            logger.info("请假申请 ID: {} 已被申请人 {} 成功取消，新状态: {}",
                    cancelledRequest.getId(), actionTaker.getUsername(), cancelledRequest.getStatusEnum());
            return populateLeaveRequestViewDto(cancelledRequest);
        } catch (IllegalStateException e) {
            logger.warn("取消操作失败 (ID: {}，操作人: {}): {}", leaveRequestId, actionTaker.getUsername(), e.getMessage());
            throw e;
        }
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<LeaveRequestViewDto> getLeaveRequestDetailsById(Long leaveRequestId) {
        logger.debug("查询请假申请详情，ID: {}", leaveRequestId);
        return leaveRequestRepository.findById(leaveRequestId)
                .map(this::populateLeaveRequestViewDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<LeaveRequestViewDto> getMyLeaveRequests(Long applicantId, Pageable pageable) {
        logger.debug("用户ID {} 查询我的请假申请，分页：{}", applicantId, pageable);
        User applicant = userRepository.findById(applicantId)
                .orElseThrow(() -> new ResourceNotFoundException("User (Applicant)", "id", applicantId));
        return leaveRequestRepository.findByApplicant(applicant, pageable)
                .map(this::populateLeaveRequestViewDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<LeaveRequestViewDto> getPendingApprovalRequestsForUser(Long approverId, LeaveStatus status, Pageable pageable) {
        LeaveStatus queryStatus = (status == null) ? LeaveStatus.PENDING_APPROVAL : status;
        logger.debug("审批人ID {} 查询状态为 {} 的请假申请列表，分页：{}", approverId, queryStatus, pageable);
        User approver = userRepository.findById(approverId)
                .orElseThrow(() -> new ResourceNotFoundException("User (Approver)", "id", approverId));
        return leaveRequestRepository.findByCurrentApproverAndStatusEnum(approver, queryStatus, pageable)
                .map(this::populateLeaveRequestViewDto);
    }

    /**
     * 【新增方法实现】管理员获取所有特定状态（默认为 PENDING_APPROVAL）的请假申请。
     */
    @Override
    @Transactional(readOnly = true)
    public Page<LeaveRequestViewDto> adminGetAllPendingRequests(LeaveStatus status, Pageable pageable) {
        LeaveStatus queryStatus = (status == null) ? LeaveStatus.PENDING_APPROVAL : status;
        logger.info("Admin 操作：获取所有状态为 {} 的请假申请，分页：{}", queryStatus, pageable);
        // 调用 Repository 中我们修改过的方法
        return leaveRequestRepository.findByStatusEnum(queryStatus, pageable)
                .map(this::populateLeaveRequestViewDto);
    }

    private LeaveRequestViewDto populateLeaveRequestViewDto(LeaveRequest leaveRequest) {
        LeaveRequestViewDto dto = LeaveRequestViewDto.fromEntity(leaveRequest);
        if (dto != null) {
            List<ApprovalHistory> histories = approvalHistoryRepository.findByLeaveRequestOrderByApprovedAtAsc(leaveRequest);
            dto.setApprovalHistory(
                    histories.stream()
                            .map(ApprovalHistoryViewDto::fromEntity)
                            .collect(Collectors.toList())
            );
            logger.trace("为请假申请ID {} 填充了 {} 条审批历史记录。", leaveRequest.getId(), histories.size());
        }
        return dto;
    }
}