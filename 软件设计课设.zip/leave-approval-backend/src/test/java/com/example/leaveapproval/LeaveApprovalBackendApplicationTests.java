package com.example.leaveapproval;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeaveApprovalBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
